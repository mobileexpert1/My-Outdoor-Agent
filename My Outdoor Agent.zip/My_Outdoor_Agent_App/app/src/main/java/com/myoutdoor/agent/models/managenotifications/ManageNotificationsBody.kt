package com.myoutdoor.agent.models.managenotifications

data class ManageNotificationsBody(
    var Notifications: Boolean
)