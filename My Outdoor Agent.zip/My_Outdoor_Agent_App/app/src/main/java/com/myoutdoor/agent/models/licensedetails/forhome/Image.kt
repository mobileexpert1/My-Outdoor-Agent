package com.myoutdoor.agent.models.licensedetails.forhome

data class Image(
    var caption: Any,
    var imageFileName: String,
    var productID: Int,
    var productImageID: Int
)