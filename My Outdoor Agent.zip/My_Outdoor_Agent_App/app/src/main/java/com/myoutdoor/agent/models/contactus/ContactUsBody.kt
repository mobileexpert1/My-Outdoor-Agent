package com.myoutdoor.agent.models.contactus

data class ContactUsBody(
    var Body: String,
    var Email: String,
    var Name: String
)