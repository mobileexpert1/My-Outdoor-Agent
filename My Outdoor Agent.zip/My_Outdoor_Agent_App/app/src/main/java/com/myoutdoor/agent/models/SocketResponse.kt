package com.myoutdoor.agent.models.SocketResponse


data class SocketResponse(
    val `data`: String,
    val messageType: Int
)