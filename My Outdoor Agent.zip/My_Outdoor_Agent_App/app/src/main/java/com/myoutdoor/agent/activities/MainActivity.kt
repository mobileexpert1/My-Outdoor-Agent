package com.myoutdoor.agent.activities



import android.view.View
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.myoutdoor.agent.R
import com.myoutdoor.agent.fragment.*
import com.myoutdoor.agent.fragment.home.HomeFragment
import com.myoutdoor.agent.fragment.message.PropertyListFragment
import com.myoutdoor.agent.fragment.search.SearchFragment
import com.myoutdoor.agent.utils.BaseActivity

class MainActivity : BaseActivity() {

    lateinit var bottomNav : BottomNavigationView

    override fun getLayoutId(): Int {
        return R.layout.activity_main
    }

    companion object {
        lateinit var mainActivity:MainActivity
    }

    override fun onLayoutCreated() {

        mainActivity = this

       // addNewFragment(HomeFragment(),R.id.container,false)
        bottomNav = findViewById(R.id.bottomNav) as BottomNavigationView
        bottomNav.visibility=View.VISIBLE
        bottomNav.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.home-> {
                    addNewFragment(HomeFragment(),R.id.container,false)
                }

                R.id.message-> {
//                    bottomNav.visibility=View.VISIBLE
                    addNewFragment(PropertyListFragment(),R.id.container,false)
                }

                R.id.search->{
//                    bottomNav.visibility=View.VISIBLE
                    addNewFragment(SearchFragment(),R.id.container,false)
                }

                R.id.profile-> {
//                    bottomNav.visibility=View.VISIBLE
                    addNewFragment(ProfileFragment(),R.id.container,false)
                }
            }
            true
        }



    }


}