package com.myoutdoor.agent.utils

class LocalData {
}