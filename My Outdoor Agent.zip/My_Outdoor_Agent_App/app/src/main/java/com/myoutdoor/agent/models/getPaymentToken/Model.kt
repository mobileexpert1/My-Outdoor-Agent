package com.myoutdoor.agent.models.getPaymentToken

data class Model(
    var message: String,
    var response: Response,
    var statusCode: Int
)