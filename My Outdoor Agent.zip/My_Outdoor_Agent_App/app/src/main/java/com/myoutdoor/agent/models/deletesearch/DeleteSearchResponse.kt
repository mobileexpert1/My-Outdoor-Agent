package com.myoutdoor.agent.models.deletesearch

data class DeleteSearchResponse(
    var message: String,
    var model: Boolean,
    var statusCode: Int
)