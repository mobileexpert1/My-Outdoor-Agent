package com.myoutdoor.agent.fragment.licence.model

data class Amenity(
    val amenities: Any,
    val amenityIcon: String,
    val amenityName: String,
    val amenityType: String,
    val amenityTypeID: Int,
    val description: String,
    val productID: Int
)