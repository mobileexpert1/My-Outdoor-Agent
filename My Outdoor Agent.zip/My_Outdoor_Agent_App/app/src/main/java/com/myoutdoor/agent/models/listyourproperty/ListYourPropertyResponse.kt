package com.myoutdoor.agent.models.listyourproperty

data class ListYourPropertyResponse(
    var message: String,
    var statusCode: Int,
    var value: Any
)