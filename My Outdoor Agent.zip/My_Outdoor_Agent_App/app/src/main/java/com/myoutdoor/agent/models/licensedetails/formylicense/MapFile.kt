package com.myoutdoor.agent.models.licensedetails.formylicense

data class MapFile(
    var countyName: Any,
    var displayName: Any,
    var mapFileID: Int,
    var mapFileName: String,
    var mapInfoJson: String,
    var productID: Int,
    var productName: Any,
    var productNo: Any,
    var regionName: Any,
    var stateName: Any
)