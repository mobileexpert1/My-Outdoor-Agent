package com.myoutdoor.agent.models.invitemember

data class InviteMemberBody(
    var LicenseContractID: String,
    var UserEmail: String
)