package com.myoutdoor.agent.models.DayPassAvailibility


data class DayPassBody(
    var daypassTotalCost: String,
    var isAvailable: Boolean
)