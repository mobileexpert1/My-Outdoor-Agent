package com.myoutdoor.agent.models.addclubmember

data class AddClubMemberResponse(

    var message: String,
    var statusCode: Int



)