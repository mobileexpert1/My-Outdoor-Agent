package com.myoutdoor.agent.models.licensedetails.formylicense.license

data class MyDetailsV2Response(
    var message: String,
    var model: Model,
    var statusCode: Int
)