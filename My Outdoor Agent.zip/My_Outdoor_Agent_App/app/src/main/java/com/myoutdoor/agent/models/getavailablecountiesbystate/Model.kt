package com.myoutdoor.agent.models.getavailablecountiesbystate

data class Model(
    var countyID: Int,
    var countyName: String,
    var countyNameLSAD: Any,
    var countyNames: Any,
    var ctfips: String,
    var regionName: Any,
    var state: Any,
    var stateAbbrev: Any,
    var stateName: Any
)