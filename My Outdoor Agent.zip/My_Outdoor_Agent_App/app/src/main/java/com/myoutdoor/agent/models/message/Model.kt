package com.myoutdoor.agent.models.message

data class Model(
    var postedDate: String,
    var productID: Int,
    var productNo: String,
    var unreadCount: Int
)