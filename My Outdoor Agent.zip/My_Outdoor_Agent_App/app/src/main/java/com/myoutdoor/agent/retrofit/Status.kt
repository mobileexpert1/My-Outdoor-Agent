package com.myoutdoor.agent.retrofit

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}