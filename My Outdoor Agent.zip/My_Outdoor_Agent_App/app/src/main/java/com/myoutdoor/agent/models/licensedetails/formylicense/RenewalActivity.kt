package com.myoutdoor.agent.models.licensedetails.formylicense

data class RenewalActivity(
    var licenseActivityID: Int,
    var paymentDueDate: String,
    var publicKey: Any
)