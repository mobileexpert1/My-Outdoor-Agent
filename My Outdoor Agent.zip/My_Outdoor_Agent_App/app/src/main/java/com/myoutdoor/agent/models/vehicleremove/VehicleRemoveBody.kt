package com.myoutdoor.agent.models.vehicleremove

data class VehicleRemoveBody(
    var VehicleDetailID: String
)