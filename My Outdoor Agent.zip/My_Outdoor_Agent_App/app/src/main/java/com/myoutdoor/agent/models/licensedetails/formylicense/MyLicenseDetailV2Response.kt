package com.myoutdoor.agent.models.licensedetails.formylicense

data class MyLicenseDetailV2Response(
    var message: String,
    var model: Model,
    var statusCode: Int
)