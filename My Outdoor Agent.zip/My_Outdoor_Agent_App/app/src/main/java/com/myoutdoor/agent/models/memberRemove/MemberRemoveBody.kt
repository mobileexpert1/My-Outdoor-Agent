package com.myoutdoor.agent.models.memberRemove

data class MemberRemoveBody(
    var LicenseContractMemberID: String
)