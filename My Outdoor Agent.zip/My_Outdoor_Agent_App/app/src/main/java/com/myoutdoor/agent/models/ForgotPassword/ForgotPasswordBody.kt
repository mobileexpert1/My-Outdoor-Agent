package com.myoutdoor.agent.models.ForgotPassword

data class ForgotPasswordBody(
    var Email:String

)
