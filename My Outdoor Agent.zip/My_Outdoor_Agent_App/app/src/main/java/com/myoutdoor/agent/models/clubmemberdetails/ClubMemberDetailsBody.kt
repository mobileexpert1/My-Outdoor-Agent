package com.myoutdoor.agent.models.clubmemberdetails

data class ClubMemberDetailsBody(
    var LicenseContractID: Int
)