package com.myoutdoor.agent.models.invitemember

data class InviteMemberResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)