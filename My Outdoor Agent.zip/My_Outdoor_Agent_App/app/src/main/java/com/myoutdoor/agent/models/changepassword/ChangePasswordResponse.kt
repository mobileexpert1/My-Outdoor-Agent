package com.myoutdoor.agent.models.changepassword

data class ChangePasswordResponse(
    var statusCode: Int,
    var message: String,
    var value: Any
)