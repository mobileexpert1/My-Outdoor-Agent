package com.myoutdoor.agent.fragment.search

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myoutdoor.agent.models.getallamenities.GetAllAmenitiesResponse
import com.myoutdoor.agent.models.getavailablecountiesbystate.GetAvailableCountiesByStateBody
import com.myoutdoor.agent.models.getavailablecountiesbystate.GetAvailableCountiesByStateResponse
import com.myoutdoor.agent.models.getavailablestates.GetAvailableStatesResponse
import com.myoutdoor.agent.models.savedsearches.postsavedsearches.PostSaveSearchesBody
import com.myoutdoor.agent.models.savedsearches.postsavedsearches.PostSaveSearchesResponse
import com.myoutdoor.agent.models.savedsearches.searchautofill.SearchAutoFillBody
import com.myoutdoor.agent.models.savedsearches.searchautofill.SearchAutoFillResponse
import com.myoutdoor.agent.models.search.SearchBody
import com.myoutdoor.agent.models.search.SearchResponse
import com.myoutdoor.agent.retrofit.ApiClient
import com.myoutdoor.agent.retrofit.ResponseHandler
import com.myoutdoor.agent.utils.BaseViewModel
import kotlinx.coroutines.launch

class SearchViewModel: BaseViewModel() {

    var getAvailableStatesResponseSuccess = MutableLiveData<GetAvailableStatesResponse>()
    var getAllAmenitiesResponseSuccess = MutableLiveData<GetAllAmenitiesResponse>()
    var postSaveSearchesResponse = MutableLiveData<PostSaveSearchesResponse>()
    var searchAutoFillResponseSuccess = MutableLiveData<SearchAutoFillResponse>()
    var searchResponseSuccess = MutableLiveData<SearchResponse>()
    var getAvailableCountiesByStateResponseSuccess = MutableLiveData<GetAvailableCountiesByStateResponse>()

    fun getAvailableCountiesByStateRequest(getAvailableCountiesByStateBody: GetAvailableCountiesByStateBody, token:String){

        viewModelScope.launch {
            isLoading.value = true
            try {
                var apiClient = ApiClient.getApiClientWithHeader(token)!!
                var response = ResponseHandler().handleSuccess(
                    apiClient.getAvailableCountiesByStateRequest(
                        getAvailableCountiesByStateBody
                    )
                )
                isLoading.value = false

                var data = response.data

                if (data!!.statusCode == 200) {
                    getAvailableCountiesByStateResponseSuccess.value = response.data!!
                } else {
                    apiError.value = data.message
                }

            } catch (e: Exception) {
                var exception = ResponseHandler().handleException<String>(e)
                apiError.value = exception.message.toString()
                isLoading.value = false
            }

        }

    }


    fun searchRequest(searchBody: SearchBody, token:String){

        viewModelScope.launch {
            isLoading.value = true
            try {
                var apiClient = ApiClient.getApiClientWithHeader(token)!!
                var response = ResponseHandler().handleSuccess(
                    apiClient.searchRequest(
                        searchBody
                    )
                )
                isLoading.value = false

                var data = response.data

                if (data!!.statusCode == 200) {
                    searchResponseSuccess.value = response.data!!
                } else {
                    apiError.value = data.message
                }

            } catch (e: Exception) {
                var exception = ResponseHandler().handleException<String>(e)
                apiError.value = exception.message.toString()
                isLoading.value = false
            }

        }

    }



    fun searchAutoFillRequest(searchAutoFillBody: SearchAutoFillBody, token:String){

        viewModelScope.launch {
          //  isLoading.value = true
            try {
                var apiClient = ApiClient.getApiClientWithHeader(token)!!
                var response = ResponseHandler().handleSuccess(
                    apiClient.searchAutoFillRequest(
                        searchAutoFillBody
                    )
                )
              //  isLoading.value = false

                var data = response.data

                if (data!!.statusCode == 200) {
                    searchAutoFillResponseSuccess.value = response.data!!
                } else {
                    apiError.value = data.message
                }

            } catch (e: Exception) {
                var exception = ResponseHandler().handleException<String>(e)

                if (exception.message.toString().equals("Something went wrong")){

                }
                else{
                    apiError.value = exception.message.toString()

                }
                isLoading.value = false

            }

        }

    }

    fun postSaveSearchesRequest(postSaveSearchesBody: PostSaveSearchesBody, token:String){

        viewModelScope.launch {
            isLoading.value = true
            try {
                var apiClient = ApiClient.getApiClientWithHeader(token)!!
                var response = ResponseHandler().handleSuccess(
                    apiClient.postSaveSearchesRequest(
                        postSaveSearchesBody
                    )
                )
                isLoading.value = false

                var data = response.data

                if (data!!.statusCode == 200) {
                    postSaveSearchesResponse.value = response.data!!
                } else {
                    apiError.value = data.message
                }

            } catch (e: Exception) {
                var exception = ResponseHandler().handleException<String>(e)
                apiError.value = exception.message.toString()
                isLoading.value = false
            }

        }

    }

    fun getAllAmenitiesRequest(token:String) {
        viewModelScope.launch {
            isLoading.value = true

            try {
                var apiClient = ApiClient.getApiClientWithHeader(token)!!
                var response = ResponseHandler().handleSuccess(
                    apiClient.getAllAmenitiesRequest()
                )
                isLoading.value = false

                Log.e("call","DATA "+response.data!!.toString())

                var data = response.data

                if (data!!.statusCode == 200) {
                    getAllAmenitiesResponseSuccess.value = data!!
                } else {
                    apiError.value = data.message
                }

            } catch (e: Exception) {
                var exception = ResponseHandler().handleException<String>(e)
                apiError.value = exception.message.toString()
                isLoading.value = false
            }

        }

    }

    fun getAvailableStatesRequest(token:String) {
        viewModelScope.launch {
            isLoading.value = true

            try {
                var apiClient = ApiClient.getApiClientWithHeader(token)!!
                var response = ResponseHandler().handleSuccess(
                    apiClient.getAvailableStatesRequest()
                )
                isLoading.value = false

                Log.e("call","DATA "+response.data!!.toString())

                var data = response.data

                if (data!!.statusCode == 200) {
                    getAvailableStatesResponseSuccess.value = data!!
                } else {
                    apiError.value = data.message
                }

            } catch (e: Exception) {
                var exception = ResponseHandler().handleException<String>(e)
                apiError.value = exception.message.toString()
                isLoading.value = false
            }

        }

    }

}