package com.myoutdoor.agent.utils


object Constants {

    const val AUTH_TOKEN="auth_token"
    var SHARED_PREF: String="com.myoutdoor.agent"
    var SHARED_PREF2: String="com.myoutdoor.agent2jg"

    //Developer

    // const val BASE_URL = "https://datav2.myoutdooragent.com/api/"

    const val BASE_URL= "https://services.myoutdooragent.com/api/"

    // Action

    const val ACTION_CHECK_NETWORK = "network_check"
    const val TOKEN = "TOKEN"
    var IS_ACTIVE = "IsActive"
    var IS_MEMBER = "IsMember"
    var IS_PENDING = "IsPending"
    var IS_EXPIRED = "IsExpired"
    var TOGGLE_SWITCH = "Toggle_Switch"
    var IS_HOME_API_HIT = "IS_HOME_API_HIT"
//https://adminv2.myoutdooragent.com/icon/8.png

    // Bundle Identifier
    const val IS_FROM_LOGIN=  "isFromLogin"
    const val USER_NAME =  "username"
    const val IS_CHECKED =  "Is_Checked"
    const val EMAIL =  "Email"
    const val USER_EMAIL =  "user_email"
    const val PASSWORD =  "Password"
    const val userAccountID =  "userAccountID"
    const val PAYMENT_TOKEN ="payment_token"

// Image Base Url

/*
     const val PROPERTY_IMAGE_URL= "https://adminv2.myoutdooragent.com/RLU_Images/"
     const val AMENITIES_URL= "https://adminv2.myoutdooragent.com/"
     const val PDF_URL= "https://datav2.myoutdooragent.com/"//https://adminv2.myoutdooragent.com/
     const val MAPS_URL= "https://adminv2.myoutdooragent.com/Assets/MapFiles/"
     const val LICENSE_AMENITIES_URL= "https://adminv2.myoutdooragent.com/icon/"
     const val IMAGE_URL = "https://adminv2.myoutdooragent.com/RLU_Images/"
     const val PAYMENT_TOKEN_BASE_URL  = "https://testoneconnect.myoutdooragent.com/payment/"
*/


    const val PROPERTY_IMAGE_URL= "https://client.myoutdooragent.com/RLU_Images/"
    const val AMENITIES_URL= "https://client.myoutdooragent.com/"
    const val PDF_URL= "https://services.myoutdooragent.com/api/"
    const val MAPS_URL= "https://client.myoutdooragent.com/Assets/MapFiles/"
    const val LICENSE_AMENITIES_URL= "https://client.myoutdooragent.com/icon/"
    const val IMAGE_URL = "https://client.myoutdooragent.com/RLU_Images/"
    const val PAYMENT_TOKEN_BASE_URL  = "https://services.myoutdooragent.com/api/payment/"


}