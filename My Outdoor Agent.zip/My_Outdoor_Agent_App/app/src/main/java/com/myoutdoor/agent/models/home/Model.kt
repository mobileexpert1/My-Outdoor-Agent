package com.myoutdoor.agent.models.home

data class Model(
    var regionName: String,
    var rLURegionModel: ArrayList<RLURegionModel>
)