package com.myoutdoor.agent.fragment.licence.model

data class LicenceKeyBody(
    var PublicKey: String
)
