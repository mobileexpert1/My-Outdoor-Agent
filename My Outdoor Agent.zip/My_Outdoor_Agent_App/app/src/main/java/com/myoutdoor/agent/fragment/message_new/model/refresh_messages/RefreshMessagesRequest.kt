package com.myoutdoor.agent.fragment.message_new.model.refresh_messages

data class RefreshMessagesRequest(
    var ProductID: Int,
    var UserMsgID: Int
)