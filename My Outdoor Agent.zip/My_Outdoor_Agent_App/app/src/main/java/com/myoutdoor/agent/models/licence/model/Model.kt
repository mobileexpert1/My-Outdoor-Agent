package com.myoutdoor.agent.fragment.licence.model

data class Model(
    val activityDetail: ActivityDetail,
    val activityDetailPageChecks: ActivityDetailPageChecks,
    val amenities: List<Amenity>,
    val clientDetails: ClientDetails,
    val images: List<Image>,
    val mapFiles: Any,
    val members: Any,
    val similarProperties: List<SimilarProperty>,
    val specialConditions:  List<SpecialCondition>
)