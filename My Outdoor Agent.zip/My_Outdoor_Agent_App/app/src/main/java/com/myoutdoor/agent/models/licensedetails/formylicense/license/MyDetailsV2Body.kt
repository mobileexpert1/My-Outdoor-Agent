package com.myoutdoor.agent.models.licensedetails.formylicense.license

data class MyDetailsV2Body(
    var PublicKey: String
)
