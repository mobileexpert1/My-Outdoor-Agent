package com.myoutdoor.agent.fragment.mylicences

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.myoutdoor.agent.R
import com.myoutdoor.agent.activities.MainActivity
import com.myoutdoor.agent.adapter.HorizontalAdapter
import com.myoutdoor.agent.adapter.MyLicencesAdapter
import com.myoutdoor.agent.fragment.licenseviewdetails.formylicenses.LicenceAnotherFragment
import com.myoutdoor.agent.models.mylicences.activelicences.Model
import com.myoutdoor.agent.models.mylicences.expiredlicences.ExpiredLicencesModel
import com.myoutdoor.agent.models.mylicences.memberoflicences.MemberModel
import com.myoutdoor.agent.models.mylicences.pendinglicences.PendingModel
import com.myoutdoor.agent.utils.BaseFragment
import com.myoutdoor.agent.utils.Constants
import com.myoutdoor.agent.utils.SharedPref
import kotlinx.android.synthetic.main.fragment_my_licences.*
import kotlinx.android.synthetic.main.toolbar.*


class MyLicencesFragment : BaseFragment(),MyLicencesAdapter.OnItemClickListener,HorizontalAdapter.OnItemClickListener {

    lateinit var viewModel: MyLicencesViewModel
    lateinit var pref: SharedPref
    lateinit var myLicencesResponseList: ArrayList<Model>
    lateinit var memberOfLicencesResponseList: ArrayList<MemberModel>
    lateinit var pendingInvitesLicencesResponseList: ArrayList<PendingModel>
    lateinit var expiredLicencesResponseList: ArrayList<ExpiredLicencesModel>
    lateinit var myLicencesAdapter : MyLicencesAdapter
    val bundle = Bundle()
    var horizontalPosition=0

    override fun getLayoutId(): Int {
        return R.layout.fragment_my_licences
    }

    override fun onCreateView() {
        pref= SharedPref(requireContext())
        viewModel = ViewModelProvider(this).get(MyLicencesViewModel::class.java)
        myLicencesResponseList = ArrayList()
        memberOfLicencesResponseList = ArrayList()
        pendingInvitesLicencesResponseList = ArrayList()
        expiredLicencesResponseList = ArrayList()

        tvToolbar.setText("My Licenses")
//        backpress button
        ivBackpress.setOnClickListener {
            requireActivity().onBackPressed()
            MainActivity.mainActivity.bottomNav.visibility= View.VISIBLE
        }

//        rvMyLicences.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
//        //creating a  arraylist of data
//        val data: ArrayList<String> = ArrayList()
//        data.add("Active")
//        data.add("Member")
//        data.add("Pending")
//        data.add("Expired")
//        rvMyLicences.adapter = HorizontalAdapter(data,this)
//
//        myLicencesAdapter = MyLicencesAdapter(requireActivity(),myLicencesResponseList, memberOfLicencesResponseList,pendingInvitesLicencesResponseList,expiredLicencesResponseList,this@MyLicencesFragment,this)
//        gv_items.adapter = myLicencesAdapter


        myLicencesAdapter = MyLicencesAdapter(requireActivity(),myLicencesResponseList, memberOfLicencesResponseList,pendingInvitesLicencesResponseList,expiredLicencesResponseList,this@MyLicencesFragment,this)
        gv_items.adapter = myLicencesAdapter

        byDefaultActive()


        tvActive.setOnClickListener {
            byDefaultActive()
            pref.setBoolean(Constants.IS_ACTIVE,true)
            pref.setBoolean(Constants.IS_MEMBER,false)
            pref.setBoolean(Constants.IS_PENDING,false)
            pref.setBoolean(Constants.IS_EXPIRED,false)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.mylicensesRequest(pref.getString(Constants.TOKEN))
        }

        tvMember.setOnClickListener {


            tvMember.setBackgroundResource(R.drawable.login_register_shape_green)
            tvMember.setTextColor(Color.parseColor("#ffffff"))

            tvActive.setBackgroundResource(R.drawable.my_licences_white_button)
            tvActive.setTextColor(Color.parseColor("#FF000000"))

            tvPending.setBackgroundResource(R.drawable.my_licences_white_button)
            tvPending.setTextColor(Color.parseColor("#FF000000"))

            tvExpired.setBackgroundResource(R.drawable.my_licences_white_button)
            tvExpired.setTextColor(Color.parseColor("#FF000000"))


            pref.setBoolean(Constants.IS_ACTIVE,false)
            pref.setBoolean(Constants.IS_MEMBER,true)
            pref.setBoolean(Constants.IS_PENDING,false)
            pref.setBoolean(Constants.IS_EXPIRED,false)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.memberOfLicencesRequest(pref.getString(Constants.TOKEN))

        }



        tvPending.setOnClickListener {

            tvPending.setBackgroundResource(R.drawable.login_register_shape_green)
            tvPending.setTextColor(Color.parseColor("#ffffff"))

            tvActive.setBackgroundResource(R.drawable.my_licences_white_button)
            tvActive.setTextColor(Color.parseColor("#FF000000"))

            tvMember.setBackgroundResource(R.drawable.my_licences_white_button)
            tvMember.setTextColor(Color.parseColor("#FF000000"))

            tvExpired.setBackgroundResource(R.drawable.my_licences_white_button)
            tvExpired.setTextColor(Color.parseColor("#FF000000"))

            pref.setBoolean(Constants.IS_ACTIVE,false)
            pref.setBoolean(Constants.IS_MEMBER,false)
            pref.setBoolean(Constants.IS_PENDING,true)
            pref.setBoolean(Constants.IS_EXPIRED,false)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.pendingInvitesLicencesRequest(pref.getString(Constants.TOKEN))
        }

        tvExpired.setOnClickListener {

            tvExpired.setBackgroundResource(R.drawable.login_register_shape_green)
            tvExpired.setTextColor(Color.parseColor("#ffffff"))

            tvActive.setBackgroundResource(R.drawable.my_licences_white_button)
            tvActive.setTextColor(Color.parseColor("#FF000000"))

            tvMember.setBackgroundResource(R.drawable.my_licences_white_button)
            tvMember.setTextColor(Color.parseColor("#FF000000"))

            tvPending.setBackgroundResource(R.drawable.my_licences_white_button)
            tvPending.setTextColor(Color.parseColor("#FF000000"))

            pref.setBoolean(Constants.IS_ACTIVE,false)
            pref.setBoolean(Constants.IS_MEMBER,false)
            pref.setBoolean(Constants.IS_PENDING,false)
            pref.setBoolean(Constants.IS_EXPIRED,true)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.expiredLicencesRequest(pref.getString(Constants.TOKEN))
        }


        fragmentBackPressHandle()

        //    viewModel.mylicensesRequest(pref.getString(Constants.TOKEN))

        setObserver()

        pref.setBoolean(Constants.IS_ACTIVE,true)
        pref.setBoolean(Constants.IS_MEMBER,false)
        pref.setBoolean(Constants.IS_PENDING,false)
        pref.setBoolean(Constants.IS_EXPIRED,false)
        tvNoDataFound.visibility = View.GONE
        memberOfLicencesResponseList.clear()
        pendingInvitesLicencesResponseList.clear()
        expiredLicencesResponseList.clear()
        myLicencesResponseList.clear()
        viewModel.mylicensesRequest(pref.getString(Constants.TOKEN))

    }

    private fun byDefaultActive() {

        tvActive.setBackgroundResource(R.drawable.login_register_shape_green)
        tvActive.setTextColor(Color.parseColor("#ffffff"))

        tvMember.setBackgroundResource(R.drawable.my_licences_white_button)
        tvMember.setTextColor(Color.parseColor("#FF000000"))

        tvPending.setBackgroundResource(R.drawable.my_licences_white_button)
        tvPending.setTextColor(Color.parseColor("#FF000000"))

        tvExpired.setBackgroundResource(R.drawable.my_licences_white_button)
        tvExpired.setTextColor(Color.parseColor("#FF000000"))

    }






    override fun onClick(index: Int) {
//        horizontalPosition=index
        if(pref.getBoolean(Constants.IS_ACTIVE)==true){
            var publickey2=myLicencesResponseList.get(index).publicKey
            bundle.putString("publickey2", publickey2)
            Log.e("call","publickey2 Active "+publickey2)
            val fragment = LicenceAnotherFragment()
            val bundle = Bundle()
            bundle.putString("publickey2", publickey2)
            fragment.setArguments(bundle)
            addNewFragment(fragment,R.id.container,true)
        } else if (pref.getBoolean(Constants.IS_MEMBER)==true){
            var publickey2=memberOfLicencesResponseList.get(index).publicKey
            bundle.putString("publickey2", publickey2)
            Log.e("call","publickey2 Member "+publickey2)
            val fragment = LicenceAnotherFragment()
            val bundle = Bundle()
            bundle.putString("publickey2", publickey2)
            fragment.setArguments(bundle)
            addNewFragment(fragment,R.id.container,true)
        }

//        replaceFragment(LicenceAnotherFragment(),R.id.container,true)

    }

    fun setObserver() {


        viewModel.myLicencesSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")

            Log.e("call","list "+it!!.model.toString())

            if (it!!.model.size > 0){
                tvNoDataFound.visibility = View.GONE
            }else{
                tvNoDataFound.visibility = View.VISIBLE
            }

//            memberOfLicencesResponseList.clear()
//            pendingInvitesLicencesResponseList.clear()
//            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            myLicencesResponseList.addAll(it!!.model)
         //   myLicencesAdapter.notifyDataSetChanged()
            myLicencesAdapter = MyLicencesAdapter(requireActivity(),myLicencesResponseList, memberOfLicencesResponseList,pendingInvitesLicencesResponseList,expiredLicencesResponseList,this@MyLicencesFragment,this)
            gv_items.adapter = myLicencesAdapter

            // check for unactivated account
            gv_items.smoothScrollToPosition(0)
        }
        )

        viewModel.memberOfLicencesSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")

            Log.e("call","list "+it!!.model.toString())

            if (it!!.model.size > 0){
                tvNoDataFound.visibility = View.GONE
            }else{
                tvNoDataFound.visibility = View.VISIBLE
            }
//            myLicencesResponseList.clear()
//            pendingInvitesLicencesResponseList.clear()
//            expiredLicencesResponseList.clear()
            memberOfLicencesResponseList.clear()
            memberOfLicencesResponseList.addAll(it!!.model)
          //  myLicencesAdapter.notifyDataSetChanged()

            myLicencesAdapter = MyLicencesAdapter(requireActivity(),myLicencesResponseList, memberOfLicencesResponseList,pendingInvitesLicencesResponseList,expiredLicencesResponseList,this@MyLicencesFragment,this)
            gv_items.adapter = myLicencesAdapter

            // check for unactivated account
            gv_items.smoothScrollToPosition(0)
        }
        )

        viewModel.pendingInvitesLicencesSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")
            if (it!!.model.size > 0){
                tvNoDataFound.visibility = View.GONE
            }else{
                tvNoDataFound.visibility = View.VISIBLE
            }
            Log.e("call","list "+it!!.model.toString())
//            myLicencesResponseList.clear()
//            expiredLicencesResponseList.clear()
//            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.addAll(it!!.model)
         //   myLicencesAdapter.notifyDataSetChanged()

            myLicencesAdapter = MyLicencesAdapter(requireActivity(),myLicencesResponseList, memberOfLicencesResponseList,pendingInvitesLicencesResponseList,expiredLicencesResponseList,this@MyLicencesFragment,this)
            gv_items.adapter = myLicencesAdapter
            // check for unactivated account

            gv_items.smoothScrollToPosition(0)
        }
        )

        viewModel.expiredLicencesSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")
            if (it!!.model.size > 0){
                tvNoDataFound.visibility = View.GONE
            }else{
                tvNoDataFound.visibility = View.VISIBLE
            }
            Log.e("call","list "+it!!.model.toString())

//            myLicencesResponseList.clear()
//            memberOfLicencesResponseList.clear()
//            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            expiredLicencesResponseList.addAll(it!!.model)
         //   myLicencesAdapter.notifyDataSetChanged()

            myLicencesAdapter = MyLicencesAdapter(requireActivity(),myLicencesResponseList, memberOfLicencesResponseList,pendingInvitesLicencesResponseList,expiredLicencesResponseList,this@MyLicencesFragment,this)
            gv_items.adapter = myLicencesAdapter
            // check for unactivated account

            gv_items.smoothScrollToPosition(0)
           }
        )

        viewModel.apiError.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed")
          //  showShortToast(it)
        }
        )

        viewModel.isLoading.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed")
            if (it) {
                progressBarPB.show()
            }
            else {
                progressBarPB.dismiss()
            }
        })

    }

    override fun onChatListListener(index: Int) {

        Log.e("call","index "+index)
        viewModel = ViewModelProvider(this).get(MyLicencesViewModel::class.java)

        if (index==0){
            pref.setBoolean(Constants.IS_ACTIVE,true)
            pref.setBoolean(Constants.IS_MEMBER,false)
            pref.setBoolean(Constants.IS_PENDING,false)
            pref.setBoolean(Constants.IS_EXPIRED,false)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.mylicensesRequest(pref.getString(Constants.TOKEN))

        }else if (index==1){
            pref.setBoolean(Constants.IS_ACTIVE,false)
            pref.setBoolean(Constants.IS_MEMBER,true)
            pref.setBoolean(Constants.IS_PENDING,false)
            pref.setBoolean(Constants.IS_EXPIRED,false)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.memberOfLicencesRequest(pref.getString(Constants.TOKEN))

        }else if(index==2){
            pref.setBoolean(Constants.IS_ACTIVE,false)
            pref.setBoolean(Constants.IS_MEMBER,false)
            pref.setBoolean(Constants.IS_PENDING,true)
            pref.setBoolean(Constants.IS_EXPIRED,false)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.pendingInvitesLicencesRequest(pref.getString(Constants.TOKEN))

        }else if (index==3){
            pref.setBoolean(Constants.IS_ACTIVE,false)
            pref.setBoolean(Constants.IS_MEMBER,false)
            pref.setBoolean(Constants.IS_PENDING,false)
            pref.setBoolean(Constants.IS_EXPIRED,true)
            tvNoDataFound.visibility = View.GONE
            memberOfLicencesResponseList.clear()
            pendingInvitesLicencesResponseList.clear()
            expiredLicencesResponseList.clear()
            myLicencesResponseList.clear()
            viewModel.expiredLicencesRequest(pref.getString(Constants.TOKEN))
        }


    }


}