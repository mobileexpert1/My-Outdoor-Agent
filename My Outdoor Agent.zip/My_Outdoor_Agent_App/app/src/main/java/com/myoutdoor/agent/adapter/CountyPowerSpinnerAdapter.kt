package com.myoutdoor.agent.adapter

import androidx.recyclerview.widget.RecyclerView
import com.skydoves.powerspinner.PowerSpinnerInterface
import com.skydoves.powerspinner.PowerSpinnerView

class CountyPowerSpinnerAdapter
{

}