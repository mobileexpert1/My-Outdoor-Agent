package com.myoutdoor.agent.models.licensedetails.forhome

data class LicenseNowViewDetailResponse(
    var message: String,
    var model: Model,
    var statusCode: Int
)