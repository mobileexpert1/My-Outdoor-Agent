package com.myoutdoor.agent.fragment.message_new.model.send_messages

data class SendMessageRequest(
    val MessageText: String,
    val ProductID: Int
)