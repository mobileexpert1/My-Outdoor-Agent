package com.myoutdoor.agent.fragment.message_new.model.get_messages

data class GetAllMessagesRequest(
    var ProductID: Int
)