package com.myoutdoor.agent.models.licensedetails.forhome

data class LicenceViewDetailHomeBody(
    var PublicKey: String
)