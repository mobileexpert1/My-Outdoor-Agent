package com.myoutdoor.agent.viewmodel

data class ItemsViewModel( val permitTV: String, val dateTV: String,val timeTV: String) {
}