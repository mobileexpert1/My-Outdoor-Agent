package com.mitsubishi.models.aboutUs

data class AboutUsResponse(
    val description: String,
    val id: String
)