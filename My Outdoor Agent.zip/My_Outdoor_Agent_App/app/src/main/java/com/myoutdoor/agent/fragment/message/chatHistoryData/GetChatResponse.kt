package com.myoutdoor.agent.fragment.message.chatHistoryData

class GetChatResponse : ArrayList<GetChatResponseItem>()