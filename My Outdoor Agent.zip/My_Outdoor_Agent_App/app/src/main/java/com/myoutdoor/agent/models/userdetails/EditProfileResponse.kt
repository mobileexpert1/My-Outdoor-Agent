package com.myoutdoor.agent.models.userdetails

data class EditProfileResponse(
    var message: String,
    var statusCode: Int,
    var value: Any
)