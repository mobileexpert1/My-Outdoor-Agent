package com.myoutdoor.agent.models.clubmemberdetails

data class ClubMemberDetailsResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)