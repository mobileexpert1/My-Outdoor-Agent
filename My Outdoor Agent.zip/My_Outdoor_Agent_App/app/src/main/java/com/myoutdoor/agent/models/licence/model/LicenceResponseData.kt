package com.myoutdoor.agent.fragment.licence.model

data class LicenceResponseData(
    val message: String,
    val model: Model,
    val statusCode: Int
)