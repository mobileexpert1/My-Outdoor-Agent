package com.myoutdoor.agent.models.vehicleremove

data class VehicleRemoveResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)