package com.myoutdoor.agent.models.deletesearch

data class DeleteSearchBody(
    var UserSearchID: String
)