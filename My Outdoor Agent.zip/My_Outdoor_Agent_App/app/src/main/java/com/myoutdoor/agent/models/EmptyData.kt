package com.myoutdoor.agent.models

class EmptyData {
}