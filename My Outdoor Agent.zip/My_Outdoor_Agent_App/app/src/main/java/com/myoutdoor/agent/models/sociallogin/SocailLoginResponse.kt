package com.myoutdoor.agent.models.sociallogin

data class SocailLoginResponse(
    var message: String,
    var model: Model,
    var statusCode: Int
)