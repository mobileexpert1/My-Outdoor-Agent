package com.myoutdoor.agent.models.propertylicense

data class PropertyLicenseResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)