package com.myoutdoor.agent.models.licensedetails.formylicense

data class SpecialCondition(
    var specCndDesc: String,
    var specCndID: Int
)