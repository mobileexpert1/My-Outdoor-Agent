package com.myoutdoor.agent.utils

class BaseData<T> {
//    var status: Boolean? = null
    var message: String? = null
    var statusCode: Int? = null

    var model: T? = null
    var error :Error?  = null
}