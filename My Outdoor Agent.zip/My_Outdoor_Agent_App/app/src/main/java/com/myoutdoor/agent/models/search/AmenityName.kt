package com.myoutdoor.agent.models.search

data class AmenityName(
    var amenities: Any,
    var amenityIcon: String,
    var amenityName: String,
    var amenityType: Any,
    var amenityTypeID: Int,
    var description: String,
    var productID: Int
)