package com.myoutdoor.agent.models.preapprovalrequest.cancelrequest

data class PreApprovalCancelRequestResponse(
    val message: String,
    val statusCode: Int,
    val value: String
)