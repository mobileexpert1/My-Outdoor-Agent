package com.myoutdoor.agent.models.contactus

data class ContactUsResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)