package com.myoutdoor.agent.models.licensedetails.formylicense

data class MyLicenseDetailV2Body(
    var PublicKey: String
)