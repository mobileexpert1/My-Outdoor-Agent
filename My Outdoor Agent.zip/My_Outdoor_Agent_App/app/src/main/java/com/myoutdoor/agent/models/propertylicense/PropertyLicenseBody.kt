package com.myoutdoor.agent.models.propertylicense

data class PropertyLicenseBody(
    var LicenseContractID: Int
)