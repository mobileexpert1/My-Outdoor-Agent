package com.myoutdoor.agent.models.rightofentry

data class RightOfEntryResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)