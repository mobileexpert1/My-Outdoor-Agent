package com.myoutdoor.agent.models.getPaymentToken

data class Response(
    var paymentToken: String
)