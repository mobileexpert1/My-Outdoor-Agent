package com.myoutdoor.agent.models.getavailablecountiesbystate

data class GetAvailableCountiesByStateBody(
    var StateAbbr: String
)