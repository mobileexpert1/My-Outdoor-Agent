package com.myoutdoor.agent.fragment

import com.myoutdoor.agent.R
import com.myoutdoor.agent.utils.BaseFragment

class SplashFragment : BaseFragment() {
    override fun getLayoutId(): Int {
        return R.layout.fragment_splash
    }

    override fun onCreateView() {
    }




}