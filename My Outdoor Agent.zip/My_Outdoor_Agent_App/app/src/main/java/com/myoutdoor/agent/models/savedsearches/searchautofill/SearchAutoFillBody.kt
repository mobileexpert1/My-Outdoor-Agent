package com.myoutdoor.agent.models.savedsearches.searchautofill

data class SearchAutoFillBody(
    var SearchText: String
)