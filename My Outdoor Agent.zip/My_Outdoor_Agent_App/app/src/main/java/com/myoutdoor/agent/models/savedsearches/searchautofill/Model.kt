package com.myoutdoor.agent.models.savedsearches.searchautofill

data class Model(
    var searchResult: String,
    var type: String
)