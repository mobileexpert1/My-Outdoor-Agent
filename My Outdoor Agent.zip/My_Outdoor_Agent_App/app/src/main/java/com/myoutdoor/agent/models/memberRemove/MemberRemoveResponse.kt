package com.myoutdoor.agent.models.memberRemove

data class MemberRemoveResponse(
    var message: String,
    var model: Any,
    var statusCode: Int
)