package com.myoutdoor.agent.models.savedsearches.postsavedsearches

data class PostSaveSearchesResponse(
    var message: String,
    var model: Boolean,
    var statusCode: Int
)