package com.myoutdoor.agent.fragment.search

import android.Manifest
import android.app.Dialog
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.text.method.TextKeyListener
import android.util.Log
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.myoutdoor.agent.R
import com.myoutdoor.agent.activities.MainActivity
import com.myoutdoor.agent.adapter.*
import com.myoutdoor.agent.fragment.PreApprovalRequest.PreApprovalRequestFragment
import com.myoutdoor.agent.fragment.licence.LicenceFragment
import com.myoutdoor.agent.models.getavailablecountiesbystate.GetAvailableCountiesByStateBody
import com.myoutdoor.agent.models.getavailablestates.Model
import com.myoutdoor.agent.models.savedsearches.postsavedsearches.PostSaveSearchesBody
import com.myoutdoor.agent.models.savedsearches.searchautofill.SearchAutoFillBody
import com.myoutdoor.agent.models.search.SearchBody
import com.myoutdoor.agent.utils.BaseFragment
import com.myoutdoor.agent.utils.Constants
import com.myoutdoor.agent.utils.SharedPref
import com.skydoves.powerspinner.OnSpinnerItemSelectedListener
import com.skydoves.powerspinner.OnSpinnerOutsideTouchListener
import com.skydoves.powerspinner.PowerSpinnerView

import kotlinx.android.synthetic.main.fragment_search.*
import kotlinx.android.synthetic.main.sortby_bottom_sheet.*
//import kotlinx.android.synthetic.main.fragment_search.parentScrollview
import java.util.*
import kotlin.collections.ArrayList


class SearchFragment : BaseFragment(), SelectActivitiesAdapter.OnItemClickListener,
    SelectAmenitiesAdapter.OnItemClickListener, AdapterView.OnItemSelectedListener,
    SearchListViewGridAdapter.OnGridItemClickListener, OnMapReadyCallback {

    var statnamelist: List<String> = ArrayList<String>()
    var selectedCountylist: List<String> = ArrayList<String>()

    private lateinit var searchListViewGridAdapter: SearchListViewGridAdapter
    private lateinit var searchItemAdapter: SearchItemAdapter
    lateinit var viewModel: SearchViewModel
    lateinit var pref: SharedPref
    var stateNameList = ArrayList<String>()
    var countyNameList = ArrayList<String>()
    var getAllAvailableStatesResponseList = ArrayList<Model>()
    var getAvailableCountiesByStateResponseList =
        ArrayList<com.myoutdoor.agent.models.getavailablecountiesbystate.Model>()
    var searchResponseList = mutableListOf<com.myoutdoor.agent.models.search.Model>()
    var getallamenitiesList = ArrayList<com.myoutdoor.agent.models.getallamenities.Model>()
    lateinit var activityamenityarrayList: ArrayList<String>
    var showDialogBox: Dialog? = null
    lateinit var selectActivitiesAdapter: SelectActivitiesAdapter
    lateinit var selectAmenitiesAdapter: SelectAmenitiesAdapter
    var amenitylist1 = ArrayList<com.myoutdoor.agent.models.getallamenities.Model>()
    var amenitylist2 = ArrayList<com.myoutdoor.agent.models.getallamenities.Model>()

    //  var amenityNameList = ArrayList<AmenityName>()
    var amenityNameList = ArrayList<com.myoutdoor.agent.models.search.Model>()
    var selectedItemsActivity = ArrayList<String>()
    var selectedItemsAmenities = ArrayList<String>()
    var finalListAmenitiesActivities = ArrayList<String>()
    var statnamearray = ArrayList<String>()
    var freeTextList = ArrayList<String>()
    var dummylist = ArrayList<String>()
    var searchlist = ArrayList<com.myoutdoor.agent.models.savedsearches.searchautofill.Model>()
    var searchListItems: ArrayList<String> = ArrayList()
    lateinit var searchHere: String
    lateinit var permitsProductTypeID: String
    var normal: String? = null
    lateinit var freetextcommon: String
    var selectFromList: String? = null
    lateinit var rluProductTypeID: String

    var productTypeID: String="0"


    lateinit var item: String
    var sort: String? = null
    var order: String? = null
    var isAdapterClicked: Boolean = false
    var common: String? = null
    var commontype: String? = null
    var statename: String? = null
    var selectedCounty: String? = null
    lateinit var commonarray: ArrayList<String>

    lateinit var countyArrayList: ArrayList<String>
    val bundle = Bundle()
    var permitCheck: Boolean = true
    var rluCheck: Boolean = true

    var amenityarray: String? = null
    var amenityarrayfreet: String? = null
    var rluList: String? = null
    var countyList: String? = null
    var regionList: String? = null
    var propertyList: String? = null
    var freetext: String? = null

    lateinit var psSelectStateSearch: PowerSpinnerView
    lateinit var psCountySpinner:PowerSpinnerView


    override fun onStop() {
        super.onStop()
        Log.e("call", "@@@@ 123 onStop   ")
        searchResponseList.clear()
    }

    override fun getLayoutId(): Int {
        return R.layout.fragment_search
    }

    override fun onCreateView() {
        showDialogBox = Dialog(requireContext())
        showDialogBox!!.setContentView(R.layout.popup_adjust_filters)
        psSelectStateSearch = showDialogBox!!.findViewById<PowerSpinnerView>(R.id.psSelectStateSearch)
        psCountySpinner = showDialogBox!!.findViewById<PowerSpinnerView>(R.id.psCountySpinner) 

        MainActivity.mainActivity.bottomNav.getMenu().getItem(1).setChecked(true)

        viewModel = ViewModelProvider(this).get(SearchViewModel::class.java)
        setObserver()
       // MainActivity.mainActivity.bottomNav.is

        psSelectStateSearch.spinnerOutsideTouchListener = object : OnSpinnerOutsideTouchListener {
            override fun onSpinnerOutsideTouch(view: View, event: MotionEvent) {
                psSelectStateSearch.dismiss()
            }
        }

        pvSortBy.spinnerOutsideTouchListener = object : OnSpinnerOutsideTouchListener {
            override fun onSpinnerOutsideTouch(view: View, event: MotionEvent) {
                pvSortBy.dismiss()
            }
        }

        psCountySpinner.spinnerOutsideTouchListener = object : OnSpinnerOutsideTouchListener {
            override fun onSpinnerOutsideTouch(view: View, event: MotionEvent) {
                psCountySpinner.dismiss()
            }
        }

//        HomeFragment.homeFragment.pvSearchSelect.dismiss()

          /// set scrollview in orientation mode

        if (resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
            parentScrollview.isEnabled = false
            gv_SearchListView.isNestedScrollingEnabled = true
        } else {
            parentScrollview.isEnabled = true
            gv_SearchListView.isNestedScrollingEnabled = false
            llListViewLayout.isClickable = false

        }

        selectedItemsActivity = ArrayList()
        selectedItemsAmenities = ArrayList()
        finalListAmenitiesActivities = ArrayList()
        pref = SharedPref(requireContext())

        viewModel.getAvailableStatesRequest(pref.getString(Constants.TOKEN))
       /* showDialogBox = Dialog(requireContext())*/
        getallamenitiesList = ArrayList()
        dummylist = ArrayList()
        searchlist = ArrayList()
        searchResponseList = ArrayList()
        searchListItems = ArrayList()
        commonarray = ArrayList()
        commonarray = ArrayList()


        viewModel.getAllAmenitiesRequest(pref.getString(Constants.TOKEN))

        searchResponseList.clear()

        val homebundle = this.arguments
        if (homebundle != null) {
            amenityarray = homebundle.getString("amenityarray")
            amenityarrayfreet = homebundle.getString("amenityarrayfreet")
            rluList = homebundle.getString("rluList")
            countyList = homebundle.getString("countyList")
            regionList = homebundle.getString("regionList")
            propertyList = homebundle.getString("propertyList")
            freetext = homebundle.getString("freetext")
            Log.e("call", "amenityarray " + amenityarray)
//            Log.e("call", "fcomlist " + fcomlist)
        }


        if (amenityarray != null) {
            amenityarray = amenityarray
        } else {
            amenityarray = ""
        }

        if (amenityarrayfreet != null) {
            amenityarrayfreet = amenityarrayfreet
        } else {
            amenityarrayfreet = ""
        }

        if (permitCheck == true) {
            showDialogBox!!.cbPermits.isChecked = true
        }
        if (rluCheck == true) {
            showDialogBox!!.cbRul.isChecked = true
        }

        if (pref.getBoolean(Constants.IS_HOME_API_HIT) == true) {
            pref.setBoolean(Constants.IS_HOME_API_HIT, false)
            if (freetext != null) {
                var freetextList: List<String> = ArrayList<String>(Arrays.asList(freetext))
                var amenityfList: List<String> = ArrayList<String>(Arrays.asList(amenityarrayfreet))
                homeApiSearcht(
                    amenityfList,
                    dummylist,
                    dummylist,
                    dummylist,
                    dummylist,
                    freetextList,
                    dummylist,
                    "New Releases",
                    ""
                )
            } else {
                if (rluList != null) {
                    var amenityList: List<String> = ArrayList<String>(Arrays.asList(amenityarray))
                    var frluList: List<String> = ArrayList<String>(Arrays.asList(rluList))
                    homeApiSearcht(
                        amenityList, dummylist, dummylist, dummylist, dummylist, dummylist,
                        frluList, "New Releases", ""
                    )
                } else if (countyList != null) {
                    var amenityList: List<String> = ArrayList<String>(Arrays.asList(amenityarray))
                    var fcountyList: List<String> = ArrayList<String>(Arrays.asList(countyList))
                    homeApiSearcht(
                        amenityList, fcountyList, dummylist, dummylist, dummylist, dummylist,
                        dummylist, "New Releases", ""
                    )
                } else if (regionList != null) {
                    var amenityList: List<String> = ArrayList<String>(Arrays.asList(amenityarray))
                    var fregionList: List<String> = ArrayList<String>(Arrays.asList(regionList))
                    homeApiSearcht(
                        amenityList, dummylist, dummylist, fregionList, dummylist, dummylist,
                        dummylist, "New Releases", ""
                    )
                } else if (propertyList != null) {
                    var amenityList: List<String> = ArrayList<String>(Arrays.asList(amenityarray))
                    var fpropertyList: List<String> = ArrayList<String>(Arrays.asList(propertyList))
                    homeApiSearcht(
                        amenityList, dummylist, dummylist, dummylist, fpropertyList, dummylist,
                        dummylist, "New Releases", ""
                    )
                }
            }


        } else {
            if (rluCheck == true && permitCheck == true) {
                productTypeID = "0"
                dummySearchApiHit(productTypeID)
            } else if (permitCheck == false && rluCheck == true) {
                productTypeID = "1"
                dummySearchApiHit(productTypeID)
            } else if (permitCheck == true && rluCheck == false) {
                productTypeID = "2"
                dummySearchApiHit(productTypeID)
            } else if (permitCheck == false && rluCheck == false) {
                productTypeID = "0"
                dummySearchApiHit(productTypeID)
            }
        }


        lldropdown.setOnClickListener {
            val dialog = BottomSheetDialog(requireContext(),R.style.DialogStyle)
            //  val dialog = BottomSheetDialog(requireContext())
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(R.layout.sortby_bottom_sheet)
            dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
            dialog.behavior.setPeekHeight(0);
            dialog.show()
            val window = dialog.window
            window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            window.setLayout(
                ViewGroup.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            window.setGravity(Gravity.BOTTOM)


            var tvNewRelease=dialog.findViewById<TextView>(R.id.tvNewRelease)
            var tvPriceHTL=dialog.findViewById<TextView>(R.id.tvPriceHTL)
            var tvPriceLTH=dialog.findViewById<TextView>(R.id.tvPriceLTH)
            var tvAcresHTL=dialog.findViewById<TextView>(R.id.tvAcresHTL)
            var tvAcresLTH=dialog.findViewById<TextView>(R.id.tvAcresLTH)
            var tvCancel=dialog.findViewById<TextView>(R.id.tvCancel)

            tvNewRelease!!.setOnClickListener {
              Log.e("call","@@@callll!!!!!!")
                sort = "New Releases"
                order = ""
              dialog.dismiss()
              callSortedBy()
            }
            tvPriceHTL!!.setOnClickListener {
                sort = "Price"
                order = "desc"
                dialog.dismiss()
                callSortedBy()
            }

            tvPriceLTH!!.setOnClickListener {
                sort = "Price"
                order = "asc"
                dialog.dismiss()
                callSortedBy()
            }
            tvAcresHTL!!.setOnClickListener {
                sort = "Acres"
                order = "desc"
                dialog.dismiss()
                callSortedBy()
            }
            tvAcresLTH!!.setOnClickListener {
                sort = "Acres"
                order = "asc"
                dialog.dismiss()
                callSortedBy()
            }
            tvCancel!!.setOnClickListener {
                dialog.dismiss()
            }

        }

        /*
         pvSortBy.setOnSpinnerItemSelectedListener(object :
            OnSpinnerItemSelectedListener<String?> {
            override fun onItemSelected(
                oldIndex: Int,
                oldItem: String?,
                newIndex: Int,
                newItem: String?
            ) {
                if (newItem == "New Releases") {
                    sort = "New Releases"
                    order = ""
                } else if (newItem == "Price: High to Low") {
                    sort = "Price"
                    order = "desc"
                } else if (newItem == "Price: Low to High") {
                    sort = "Price"
                    order = "asc"
                } else if (newItem == "Acres: High to Low") {
                    sort = "Acres"
                    order = "desc"
                } else if (newItem == "Acres: Low to High") {
                    sort = "Acres"
                    order = "asc"
                }

                if (selectedCounty == null) {
                    selectedCounty = ""
                }

                if (statename == null) {
                    statename = ""
                }

                selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                statnamelist = ArrayList<String>(Arrays.asList(statename))
                listviewGreenButton()
                if (selectFromList != null) {
                    if (commontype == "RLU") {
                        priceSort(
                            selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                            fcomlist, "" + sort, "" + order
                        )
                    } else if (commontype == "County") {
                        priceSort(
                            fcomlist, statnamelist, dummylist, dummylist, dummylist,
                            dummylist, "" + sort, "" + order
                        )
                    } else if (commontype == "Region") {
                        priceSort(
                            selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                            dummylist, "" + sort, "" + order
                        )
                    } else {
                        priceSort(
                            selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                            dummylist, "" + sort, "" + order
                        )
                    }
                } else {
                    if (selectFromList == null) {
                        selectFromList = ""
                        normal = autoTextView.text.toString()
//                      freetextcommon = normal
                        var freetextlist: List<String> = ArrayList<String>(Arrays.asList(normal))
                        normal?.let { commonarray.add(it) }
                        priceSort(
                            selectedCountylist,
                            statnamelist,
                            dummylist,
                            dummylist,
                            freetextlist,
                            dummylist,
                            "" + sort,
                            "" + order
                        )
                    }
                }

            }
        })
         */

        if (order == "") {
            order = ""
        } else {
            order = order
        }

        if (sort == "") {
            sort = "New Releases"
        } else {
            sort = sort
        }

        flMap.visibility = View.GONE
        llListViewLayout.visibility = View.VISIBLE
        tvListView.setOnClickListener {
            listviewGreenButton()
        }

        tvMap.setOnClickListener {
            llResetfilterlayout.visibility = View.GONE
            checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, 1);
           // showMessageoOfMap()
            mapGreenButton()
        }

        /*  wvMapWebview.webViewClient = WebViewClient()
          wvMapWebview.settings.javaScriptEnabled = true
          wvMapWebview.loadUrl("https://www.google.com/maps/@29.1280178,103.5976885,3z")*/
        val mapFragment =requireActivity().supportFragmentManager.findFragmentById(R.id.Map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)

        checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, 1);

        searchHere = autoTextView.text.toString()
        val autoTextView = AutoCompleteTextView(requireActivity())
        val layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        autoTextView.layoutParams = layoutParams
        layoutParams.setMargins(30, 30, 30, 30)

        statnamearray.add(statename.toString())


        Log.e("call", "state name list: " + stateNameList.toString())
        showDialogBox!!.cbPermits.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener {
            override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {

                showDialogBox!!.dismiss()
//                if (p0!!.isChecked) {
                listviewGreenButton()

                if (showDialogBox!!.cbPermits.isChecked == true) {
                    permitCheck = true
                    gv_SearchListView.visibility = View.VISIBLE
                    if (rluCheck == true && permitCheck == true) {
                        productTypeID = "0"
                    } else if (permitCheck == false && rluCheck == true) {
                        productTypeID = "1"
                    } else if (permitCheck == true && rluCheck == false) {
                        productTypeID = "2"
                    } else if (permitCheck == false && rluCheck == false) {
                        productTypeID = "0"
                    }

                    selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                    var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                    statnamelist = ArrayList<String>(Arrays.asList(statename))

                    if (selectFromList != null) {
                        if (commontype == "RLU") {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                                fcomlist, "" + sort, "" + order
                            )
                        } else if (commontype == "County") {
                            priceSort(
                                fcomlist, statnamelist, dummylist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else if (commontype == "Region") {
                            priceSort(
                                selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        }
                    } else {
                        if (selectFromList == null) {
                            selectFromList = ""
                            normal = autoTextView.text.toString()
                            var freetextlist: List<String> =
                                ArrayList<String>(Arrays.asList(normal))
                            normal?.let { commonarray.add(it) }
                            priceSort(
                                selectedCountylist,
                                statnamelist,
                                dummylist,
                                dummylist,
                                freetextlist,
                                dummylist,
                                "" + sort,
                                "" + order
                            )
                        }
                    }

                } else {
                    permitCheck = false

                    if (rluCheck == true && permitCheck == true) {
                        productTypeID = "0"
                    } else if (permitCheck == false && rluCheck == true) {
                        productTypeID = "1"
                    } else if (permitCheck == true && rluCheck == false) {
                        productTypeID = "2"
                    } else if (permitCheck == false && rluCheck == false) {
                        productTypeID = "0"
                    }

                    gv_SearchListView.visibility = View.VISIBLE
                    selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                    var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                    statnamelist = ArrayList<String>(Arrays.asList(statename))

                    if (selectFromList != null) {
                        if (commontype == "RLU") {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                                fcomlist, "" + sort, "" + order
                            )
                        } else if (commontype == "County") {
                            priceSort(
                                fcomlist, statnamelist, dummylist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else if (commontype == "Region") {
                            priceSort(
                                selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        }
                    } else {
                        if (selectFromList == null) {
                            selectFromList = ""
                            normal = autoTextView.text.toString()
                            var freetextlist: List<String> =
                                ArrayList<String>(Arrays.asList(normal))
                            normal?.let { commonarray.add(it) }
                            priceSort(
                                selectedCountylist,
                                statnamelist,
                                dummylist,
                                dummylist,
                                freetextlist,
                                dummylist,
                                "" + sort,
                                "" + order
                            )
                        }
                    }

                }

            }
        })

        ivResetFilters.setOnClickListener {
            listviewGreenButton()
            productTypeID = "0"
            gv_SearchListView.visibility = View.VISIBLE
            var searchBody = SearchBody(
                dummylist,
                "",
                dummylist,
                "",
                "",
                "0",
                "0",
                productTypeID,
                dummylist,
                dummylist,
                "0",
                "0",
                "New Releases",
                dummylist,
                dummylist,
                pref.getString(Constants.userAccountID),
                dummylist,
            )
            viewModel.searchRequest(searchBody, pref.getString(Constants.TOKEN))


        }


        showDialogBox!!.cbRul.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener {

            override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {
                showDialogBox!!.dismiss()
                listviewGreenButton()
                if (showDialogBox!!.cbRul.isChecked == true) {
                    rluCheck = true
                    gv_SearchListView.visibility = View.VISIBLE
                    if (rluCheck == true && permitCheck == true) {
                        productTypeID = "0"
                    } else if (permitCheck == false && rluCheck == true) {
                        productTypeID = "1"
                    } else if (permitCheck == true && rluCheck == false) {
                        productTypeID = "2"
                    } else if (permitCheck == false && rluCheck == false) {
                        productTypeID = "0"
                    }

                    selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                    var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                    statnamelist = ArrayList<String>(Arrays.asList(statename))

                    if (selectFromList != null) {
                        if (commontype == "RLU") {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                                fcomlist, "" + sort, "" + order
                            )
                        } else if (commontype == "County") {
                            priceSort(
                                fcomlist, statnamelist, dummylist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else if (commontype == "Region") {
                            priceSort(
                                selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        }
                    } else {
                        if (selectFromList == null) {
                            selectFromList = ""
                            normal = autoTextView.text.toString()
                            var freetextlist: List<String> =
                                ArrayList<String>(Arrays.asList(normal))
                            normal?.let { commonarray.add(it) }
                            priceSort(
                                selectedCountylist,
                                statnamelist,
                                dummylist,
                                dummylist,
                                freetextlist,
                                dummylist,
                                "" + sort,
                                "" + order
                            )
                        }
                    }
                } else {
                    gv_SearchListView.visibility = View.VISIBLE
//                    productTypeID = "2"
                    rluCheck = false
                    if (rluCheck == true && permitCheck == true) {
                        productTypeID = "0"
                    } else if (permitCheck == false && rluCheck == true) {
                        productTypeID = "1"
                    } else if (permitCheck == true && rluCheck == false) {
                        productTypeID = "2"
                    } else if (permitCheck == false && rluCheck == false) {
                        productTypeID = "0"
                    }

                    selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                    var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                    statnamelist = ArrayList<String>(Arrays.asList(statename))

                    if (selectFromList != null) {
                        if (commontype == "RLU") {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                                fcomlist, "" + sort, "" + order
                            )
                        } else if (commontype == "County") {
                            priceSort(
                                fcomlist, statnamelist, dummylist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else if (commontype == "Region") {
                            priceSort(
                                selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        }
                    } else {
                        if (selectFromList == null) {
                            selectFromList = ""
                            normal = autoTextView.text.toString()
                            var freetextlist: List<String> =
                                ArrayList<String>(Arrays.asList(normal))
                            normal?.let { commonarray.add(it) }
                            priceSort(
                                selectedCountylist,
                                statnamelist,
                                dummylist,
                                dummylist,
                                freetextlist,
                                dummylist,
                                "" + sort,
                                "" + order
                            )
                        }
                    }
                }

            }
        })

        searchListViewGridAdapter = SearchListViewGridAdapter(
            requireActivity(),
            searchResponseList,
            this@SearchFragment,
            this
        )

        gv_SearchListView.adapter = searchListViewGridAdapter


        llFilterSearch.setOnClickListener {
            listviewGreenButton()

            adjustFiltersPopup()
        }

    }


    fun callSortedBy(){
        if (selectedCounty == null) {
            selectedCounty = ""
        }

        if (statename == null) {
            statename = ""
        }

        selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
        var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
        statnamelist = ArrayList<String>(Arrays.asList(statename))
        listviewGreenButton()
        if (selectFromList != null) {
            if (commontype == "RLU") {
                priceSort(
                    selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                    fcomlist, "" + sort, "" + order
                )
            } else if (commontype == "County") {
                priceSort(
                    fcomlist, statnamelist, dummylist, dummylist, dummylist,
                    dummylist, "" + sort, "" + order
                )
            } else if (commontype == "Region") {
                priceSort(
                    selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                    dummylist, "" + sort, "" + order
                )
            } else {
                priceSort(
                    selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                    dummylist, "" + sort, "" + order
                )
            }
        } else {
            if (selectFromList == null) {
                selectFromList = ""
                normal = autoTextView.text.toString()
//                      freetextcommon = normal
                var freetextlist: List<String> = ArrayList<String>(Arrays.asList(normal))
                normal?.let { commonarray.add(it) }
                priceSort(
                    selectedCountylist,
                    statnamelist,
                    dummylist,
                    dummylist,
                    freetextlist,
                    dummylist,
                    "" + sort,
                    "" + order
                )
            }
        }
    }

    fun checkPermission(permission: String, requestCode: Int) {
        if (ContextCompat.checkSelfPermission(
                requireActivity(),
                permission
            ) == PackageManager.PERMISSION_DENIED
        ) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(permission), requestCode)
        } else {

        }
    }



    fun dummySearchApiHit(producttypeID: String) {
        gv_SearchListView.visibility = View.VISIBLE
        var searchBody = SearchBody(
            dummylist,
            "",
            dummylist,
            "",
            "",
            "0",
            "0",
            producttypeID,
            dummylist,
            dummylist,
            "0",
            "0",
            "New Releases",
            dummylist,
            dummylist,
            pref.getString(Constants.userAccountID),
            dummylist,
        )
        viewModel.searchRequest(searchBody, pref.getString(Constants.TOKEN))
    }

    fun listviewGreenButton() {
        tvListView.setBackgroundResource(R.drawable.login_register_shape_green)
        tvMap.setBackgroundResource(R.drawable.account_two_tab_shape)
        tvListView.setTextColor(Color.parseColor("#FFFFFFFF"))
        tvMap.setTextColor(Color.parseColor("#FF000000"))
//          addNewFragment(LoginFragment(),R.id.mainContainer,false)
        flMap.visibility = View.GONE

        if (searchResponseList.size == 0){
            llResetfilterlayout.visibility = View.VISIBLE
            gv_SearchListView.visibility = View.GONE
        }else {
            llResetfilterlayout.visibility = View.GONE
            gv_SearchListView.visibility = View.VISIBLE
        }
    }

    fun mapGreenButton() {
        tvMap.setBackgroundResource(R.drawable.login_register_shape_green)
        tvListView.setBackgroundResource(R.drawable.account_two_tab_shape)
        tvListView.setTextColor(Color.parseColor("#FF000000"))
        tvMap.setTextColor(Color.parseColor("#FFFFFFFF"))
//          addNewFragment(SignUpFragment(),R.id.mainContainer,false)
        flMap.visibility = View.VISIBLE
        gv_SearchListView.visibility = View.GONE
    }

    fun priceSort(
        countyList: List<String>,
        stateNameList: List<String>,
        regionNameList: List<String>,
        propertynameList: List<String>,
        freeTextList: List<String>,
        rluList: List<String>,
        sort: String,
        order: String
    ) {
        var searchBody = SearchBody(
            dummylist,
            "",
            countyList,
            "",
            "" + order,
            "0",
            "0",
            productTypeID,
            propertynameList,
            rluList,
            "0",
            "0",
            "" + sort,
            regionNameList,
            stateNameList,
            pref.getString(Constants.userAccountID),
            freeTextList
        )
        viewModel.searchRequest(searchBody, pref.getString(Constants.TOKEN))
    }

    fun homeApiSearcht(
        amenitylist: List<String>,
        countyList: List<String>,
        stateNameList: List<String>,
        regionNameList: List<String>,
        propertynameList: List<String>,
        freeTextList: List<String>,
        rluList: List<String>,
        sort: String,
        order: String
    ) {
        var searchBody = SearchBody(
            amenitylist,
            "",
            countyList,
            "",
            "" + order,
            "0",
            "0",
            "0",
            propertynameList,
            rluList,
            "0",
            "0",
            "" + sort,
            regionNameList,
            stateNameList,
            pref.getString(Constants.userAccountID),
            freeTextList
        )
        viewModel.searchRequest(searchBody, pref.getString(Constants.TOKEN))
    }


    fun searchApiHit(
        countyList: List<String>,
        stateNameList: List<String>,
        regionNameList: List<String>,
        propertynameList: List<String>,
        freeTextList: List<String>,
        rluList: List<String>,
        sort: String,
        order: String,
        priceMax: String,
        priceMin: String,
        acresMax: String,
        acresMin: String,
        amenitiesList: List<String>
    ) {
        var searchBody = SearchBody(
            amenitiesList,
            "",
            countyList,
            "",
            "" + order,
            "" + priceMax,
            "" + priceMin,
            productTypeID,
            propertynameList,
            rluList,
            "" + acresMax,
            "" + acresMin,
            "" + sort,
            regionNameList,
            stateNameList,
            pref.getString(Constants.userAccountID),
            freeTextList
        )
        viewModel.searchRequest(searchBody, pref.getString(Constants.TOKEN))
    }

    fun postSavedSearchApiHit(
        countyList: List<String>,
        stateNameList: List<String>,
        regionNameList: List<String>,
        propertynameList: List<String>,
        freeTextList: List<String>,
        rluList: List<String>,
        priceMax: String,
        priceMin: String,
        acresMax: String,
        acresMin: String,
        amenitiesList: List<String>,
        searchName: String
    ) {
        val postSaveSearchesBody = PostSaveSearchesBody(
            amenitiesList,
            "",
            countyList,
            "",
            "" + priceMax,
            "" + priceMin,
            productTypeID,
            propertynameList,
            rluList,
            "" + acresMax,
            "" + acresMin,
            regionNameList,
            searchName,
            stateNameList,
            "" + pref.getString(Constants.userAccountID),
            freeTextList
        )

        viewModel.postSaveSearchesRequest(
            postSaveSearchesBody,
            pref.getString(Constants.TOKEN)
        )
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        selectedItemsActivity.clear()
        selectedItemsAmenities.clear()
        finalListAmenitiesActivities.clear()

        autoTextView.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable) {
                if (isAdapterClicked) {
                    isAdapterClicked = false
                } else {
                    var searchAutoFillBody = SearchAutoFillBody(
                        "" + autoTextView.text
                    )
                    viewModel.searchAutoFillRequest(
                        searchAutoFillBody,
                        pref.getString(Constants.TOKEN)
                    )
                }
            }
        })
    }

    private fun showSoftKeyboard(view: View) {
        if (view.requestFocus()) {
            val imm = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeSoftKeyboard(view: View) {
        if (view.requestFocus()) {
            val imm = requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
        }
    }


    private fun adjustFiltersPopup() {

   /*     showDialogBox!!.setContentView(R.layout.popup_adjust_filters)*/
        showDialogBox!!.setCanceledOnTouchOutside(true)
        showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
        val layoutManager = LinearLayoutManager(requireContext())
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        val edtAcresMin: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtAcresMin)
        val edtAcresMax: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtAcresMax)
        val edtTotalPriceMin: EditText =
            showDialogBox!!.findViewById<EditText>(R.id.edtTotalPriceMin)
        val edtTotalPriceMax: EditText =
            showDialogBox!!.findViewById<EditText>(R.id.edtTotalPriceMax)
        val tvSearch: TextView = showDialogBox!!.findViewById<TextView>(R.id.tvSearch)
        val tvSavedSearch: TextView = showDialogBox!!.findViewById<TextView>(R.id.tvSavedSearch)
        val ivClose: ImageView = showDialogBox!!.findViewById<ImageView>(R.id.ivClose)
        val ivRefresh: ImageView = showDialogBox!!.findViewById<ImageView>(R.id.ivRefresh)
        val gvSelectActivities: GridView =
            showDialogBox!!.findViewById<GridView>(R.id.gvSelectActivities)
        val gvSelectAmenities: GridView =
            showDialogBox!!.findViewById<GridView>(R.id.gvSelectAmenities)



//        set elipsize end Acress Min
//        edtAcresMin.setKeyListener(null);
//        edtAcresMin.setEllipsize(TextUtils.TruncateAt.END);


        edtAcresMin.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                //Editable status

                edtAcresMin.setEllipsize(null)
                edtAcresMin.setKeyListener(TextKeyListener(TextKeyListener.Capitalize.NONE, false))
                edtAcresMin.setInputType(InputType.TYPE_CLASS_NUMBER)

                showSoftKeyboard(v)
            } else {
                //Not editable[enter image description here][1]
                edtAcresMin.setKeyListener(null)
                edtAcresMin.setEllipsize(TextUtils.TruncateAt.END)
            }
        }

        ///  set elipsize end Acress Max
        edtAcresMax.setKeyListener(null);
        edtAcresMax.setEllipsize(TextUtils.TruncateAt.END);
        edtAcresMax.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                //Editable status

                edtAcresMax.setEllipsize(null)
                edtAcresMax.setKeyListener(TextKeyListener(TextKeyListener.Capitalize.NONE, false))
                edtAcresMax.setInputType(InputType.TYPE_CLASS_NUMBER)

                showSoftKeyboard(v)
            } else {
                //Not editable[enter image description here][1]
                edtAcresMax.setKeyListener(null)
                edtAcresMax.setEllipsize(TextUtils.TruncateAt.END)
            }
        }

        ///  set elipsize end Price Min
        edtTotalPriceMin.setKeyListener(null);
        edtTotalPriceMin.setEllipsize(TextUtils.TruncateAt.END);
        edtTotalPriceMin.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                //Editable status

                edtTotalPriceMin.setEllipsize(null)
                edtTotalPriceMin.setKeyListener(TextKeyListener(TextKeyListener.Capitalize.NONE, false))
                edtTotalPriceMin.setInputType(InputType.TYPE_CLASS_NUMBER)

                showSoftKeyboard(v)
            } else {
                //Not editable[enter image description here][1]
                edtTotalPriceMin.setKeyListener(null)
                edtTotalPriceMin.setEllipsize(TextUtils.TruncateAt.END)
            }
        }

        ///  set elipsize end Price Max
        edtTotalPriceMax.setKeyListener(null);
        edtTotalPriceMax.setEllipsize(TextUtils.TruncateAt.END);
        edtTotalPriceMax.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                //Editable status

                edtTotalPriceMax.setEllipsize(null)
                edtTotalPriceMax.setKeyListener(TextKeyListener(TextKeyListener.Capitalize.NONE, false))
                edtTotalPriceMax.setInputType(InputType.TYPE_CLASS_NUMBER)

                showSoftKeyboard(v)
            } else {
                //Not editable[enter image description here][1]
                edtTotalPriceMax.setKeyListener(null)
                edtTotalPriceMax.setEllipsize(TextUtils.TruncateAt.END)
            }
        }


        edtTotalPriceMax.setOnEditorActionListener(TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {


                edtTotalPriceMax.setEllipsize(TextUtils.TruncateAt.END)
                val imm =
                    v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(v.windowToken, 0)

                edtAcresMin.clearFocus()
                edtAcresMax.clearFocus()
                edtTotalPriceMin.clearFocus()
                edtTotalPriceMax.clearFocus()

                edtAcresMin.setKeyListener(null)
                edtAcresMin.setEllipsize(TextUtils.TruncateAt.END)

                return@OnEditorActionListener true
            }
            false
        })





        selectActivitiesAdapter =
            SelectActivitiesAdapter(requireActivity(), amenitylist1, this, this@SearchFragment)
        gvSelectActivities.adapter = selectActivitiesAdapter

        selectAmenitiesAdapter =
            SelectAmenitiesAdapter(requireActivity(), amenitylist2, this, this@SearchFragment)
        gvSelectAmenities.adapter = selectAmenitiesAdapter



        ivRefresh.setOnClickListener {


            for (item in amenitylist1) {

                if (item.isSelected == true) {
                    item.isSelected = false;
                }

            }
            for (item in amenitylist2) {

                if (item.isSelected == true) {
                    item.isSelected = false;
                }

            }


//            productTypeID = "0"
            gv_SearchListView.visibility = View.VISIBLE
            var searchBody = SearchBody(
                dummylist,
                "",
                dummylist,
                "",
                "",
                "0",
                "0",
                "0",
                dummylist,
                dummylist,
                "0",
                "0",
                "New Releases",
                dummylist,
                dummylist,
                pref.getString(Constants.userAccountID),
                dummylist,
            )
            viewModel.searchRequest(searchBody, pref.getString(Constants.TOKEN))
            showDialogBox!!.cancel()
        }


        var totalPriceMax: String = edtTotalPriceMax.text.toString()
        var totalPriceMin: String = edtTotalPriceMin.text.toString()

        if (edtTotalPriceMax.text.toString().isEmpty()) {
            totalPriceMax = ""
        } else {
            totalPriceMax = edtTotalPriceMax.text.toString()
        }

        if (edtTotalPriceMin.text.toString().isEmpty()) {
            totalPriceMin = ""
        } else {
            totalPriceMin = edtTotalPriceMax.text.toString()
        }

        tvSavedSearch.setOnClickListener {
            gv_SearchListView.visibility = View.VISIBLE
            //    finalListAmenitiesActivities.addAll(listOf((amenitylist1 + amenitylist2).toString()))
            finalListAmenitiesActivities.clear()


            for (item in amenitylist1) {

                if (item.isSelected == true) {
                    item.isSelected = false;
                }

            }
            for (item in amenitylist2) {

                if (item.isSelected == true) {
                    item.isSelected = false;
                }

            }






//            selectedItemsActivity.clear()
//            selectedItemsAmenities.clear()
            finalListAmenitiesActivities.addAll(selectedItemsActivity)
            finalListAmenitiesActivities.addAll(selectedItemsAmenities)

            Log.e("call", "@@@@ Activitylist: " + selectedItemsActivity)
            Log.e("call", "@@@@ Amenetieslist: " + selectedItemsAmenities)
            Log.e("call", "@@@@ Amenetieslist: " + finalListAmenitiesActivities)

            if (edtAcresMin.text.isEmpty()) {
                showAlert("Please enter Acres Min")
            } else if (edtTotalPriceMin.text.isEmpty()) {
                showAlert("Please enter Total price min")
            } else if (edtAcresMax.text.isEmpty()) {
                showAlert("Please enter Acres Max")
            } else if (edtTotalPriceMax.text.isEmpty()) {
                showAlert("Please enter Total price max")
            } else if (selectedItemsAmenities.isEmpty()) {
                showAlert("Please Select Amenities")
            } else if (selectedItemsActivity.isEmpty()) {
                showAlert("Please Select Activities")
            } else {
                /// hit api
//                var statnamearray: List<String> = ArrayList<String>(Arrays.asList(statename))

                if (selectedCounty == null) {
                    selectedCounty = ""
                }

                if (statename == null) {
                    statename = ""
                }

                selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                statnamelist = ArrayList<String>(Arrays.asList(statename))

                if (selectFromList != null) {
                    if (commontype == "RLU") {
                        postSavedSearchApiHit(
                            selectedCountylist,
                            statnamelist,
                            dummylist,
                            dummylist,
                            dummylist,
                            fcomlist,
                            "" + edtTotalPriceMax.text.toString(),
                            "" + edtTotalPriceMin.text.toString(),
                            "" + edtAcresMax.text.toString(),
                            "" + edtAcresMin.text.toString(),
                            finalListAmenitiesActivities,
                            selectFromList.toString()
                        )
                        showDialogBox!!.cancel()
                    } else if (commontype == "County") {
                        postSavedSearchApiHit(
                            fcomlist,
                            statnamelist,
                            dummylist,
                            dummylist,
                            dummylist,
                            dummylist,
                            "" + edtTotalPriceMax.text.toString(),
                            "" + edtTotalPriceMin.text.toString(),
                            "" + edtAcresMax.text.toString(),
                            "" + edtAcresMin.text.toString(),
                            finalListAmenitiesActivities,
                            ""
                        )
                        showDialogBox!!.cancel()
                    } else if (commontype == "Region") {
                        postSavedSearchApiHit(
                            selectedCountylist,
                            statnamelist,
                            fcomlist,
                            dummylist,
                            dummylist,
                            dummylist,
                            "" + edtTotalPriceMax.text.toString(),
                            "" + edtTotalPriceMin.text.toString(),
                            "" + edtAcresMax.text.toString(),
                            "" + edtAcresMin.text.toString(),
                            finalListAmenitiesActivities,
                            ""
                        )
                        showDialogBox!!.cancel()
                    } else {
                        postSavedSearchApiHit(
                            selectedCountylist,
                            statnamelist,
                            dummylist,
                            fcomlist,
                            dummylist,
                            dummylist,
                            "" + edtTotalPriceMax.text.toString(),
                            "" + edtTotalPriceMin.text.toString(),
                            "" + edtAcresMax.text.toString(),
                            "" + edtAcresMin.text.toString(),
                            finalListAmenitiesActivities,
                            ""
                        )
                        showDialogBox!!.cancel()
                    }
                } else {
                    if (selectFromList == null) {
                        selectFromList = ""
                        normal = autoTextView.text.toString()
                        var freetextlist: List<String> = ArrayList<String>(Arrays.asList(normal))
                        normal?.let { commonarray.add(it) }
                        postSavedSearchApiHit(
                            selectedCountylist,
                            statnamelist,
                            dummylist,
                            dummylist,
                            freetextlist,
                            dummylist,
                            "" + edtTotalPriceMax.text.toString(),
                            "" + edtTotalPriceMin.text.toString(),
                            "" + edtAcresMax.text.toString(),
                            "" + edtAcresMin.text.toString(),
                            finalListAmenitiesActivities,
                            ""
                        )
                        showDialogBox!!.cancel()
                    }
                }

                /*      val postSaveSearchesBody = PostSaveSearchesBody(
                         finalListAmenitiesActivities,
                         "",
                         dummylist, "", edtTotalPriceMax.text.toString(),
                         edtTotalPriceMin.text.toString(),
                         productTypeID, dummylist, dummylist,
                         edtAcresMax.text.toString(), edtAcresMin.text.toString(),
                         dummylist, "",
                         statnamearray,
                         "" + pref.getString(Constants.userAccountID),
                         dummylist
                     )

                     viewModel.postSaveSearchesRequest(
                         postSaveSearchesBody,
                         pref.getString(Constants.TOKEN)
                     )*/

                finalListAmenitiesActivities.clear()
                showDialogBox!!.cancel()
            }

        }

        tvSearch.setOnClickListener {

            Log.e("call", "@@@ selectedItemsActivity:-  " + selectedItemsActivity.toString())
            Log.e("call", "@@@ selectedItemsAmenities:-  " + selectedItemsAmenities.toString())

            finalListAmenitiesActivities.clear()




            for (item in amenitylist1) {

                if (item.isSelected == true) {
                    item.isSelected = false;
                }

            }
            for (item in amenitylist2) {

                if (item.isSelected == true) {
                    item.isSelected = false;
                }

            }


            finalListAmenitiesActivities.addAll(selectedItemsActivity)
            finalListAmenitiesActivities.addAll(selectedItemsAmenities)
            gv_SearchListView.visibility = View.VISIBLE

//            if (edtAcresMin.text.isEmpty()) {
//                showAlert("Please enter Acres Min")
//            } else if (edtTotalPriceMin.text.isEmpty()) {
//                showAlert("Please enter Total price min")
//            } else if (edtAcresMax.text.isEmpty()) {
//                showAlert("Please enter Acres Max")
//            } else if (edtTotalPriceMax.text.isEmpty()) {
//                showAlert("Please enter Total price max")
//            } else if (amenitylist1.isEmpty()) {
//                showAlert("Please Select Amenities")
//            } else if (amenitylist2.isEmpty()) {
//                showAlert("Please Select Activities")
//            } else {
            /// hit api
            listviewGreenButton()

            if (selectedCounty == null) {
                selectedCounty = ""
            }

            if (statename == null) {
                statename = ""
            }

            selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
            var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
            statnamelist = ArrayList<String>(Arrays.asList(statename))

            if (selectFromList != null) {
                if (commontype == "RLU") {
                    searchApiHit(
                        selectedCountylist,
                        statnamelist,
                        dummylist,
                        dummylist,
                        dummylist,
                        fcomlist,
                        "" + sort,
                        "" + order,
                        "" + edtTotalPriceMax.text.toString(),
                        "" + edtTotalPriceMin.text.toString(),
                        "" + edtAcresMax.text.toString(),
                        "" + edtAcresMin.text.toString(),
                        finalListAmenitiesActivities
                    )
                    showDialogBox!!.cancel()
                } else if (commontype == "County") {
                    searchApiHit(
                        fcomlist,
                        statnamelist,
                        dummylist,
                        dummylist,
                        dummylist,
                        dummylist,
                        "" + sort,
                        "" + order,
                        "" + edtTotalPriceMax.text.toString(),
                        "" + edtTotalPriceMin.text.toString(),
                        "" + edtAcresMax.text.toString(),
                        "" + edtAcresMin.text.toString(),
                        finalListAmenitiesActivities
                    )
                    showDialogBox!!.cancel()
                } else if (commontype == "Region") {
                    searchApiHit(
                        selectedCountylist,
                        statnamelist,
                        fcomlist,
                        dummylist,
                        dummylist,
                        dummylist,
                        "" + sort,
                        "" + order,
                        "" + edtTotalPriceMax.text.toString(),
                        "" + edtTotalPriceMin.text.toString(),
                        "" + edtAcresMax.text.toString(),
                        "" + edtAcresMin.text.toString(),
                        finalListAmenitiesActivities
                    )
                    showDialogBox!!.cancel()
                } else {
                    searchApiHit(
                        selectedCountylist,
                        statnamelist,
                        dummylist,
                        fcomlist,
                        dummylist,
                        dummylist,
                        "" + sort,
                        "" + order,
                        "" + edtTotalPriceMax.text.toString(),
                        "" + edtTotalPriceMin.text.toString(),
                        "" + edtAcresMax.text.toString(),
                        "" + edtAcresMin.text.toString(),
                        finalListAmenitiesActivities
                    )
                    showDialogBox!!.cancel()
                }
            } else {
                if (selectFromList == null) {
                    selectFromList = ""
                    normal = autoTextView.text.toString()
                    var freetextlist: List<String> = ArrayList<String>(Arrays.asList(normal))
                    normal?.let { commonarray.add(it) }
                    searchApiHit(
                        selectedCountylist,
                        statnamelist,
                        dummylist,
                        dummylist,
                        freetextlist,
                        dummylist,
                        "" + sort,
                        "" + order,
                        "" + edtTotalPriceMax.text.toString(),
                        "" + edtTotalPriceMin.text.toString(),
                        "" + edtAcresMax.text.toString(),
                        "" + edtAcresMin.text.toString(),
                        finalListAmenitiesActivities
                    )
                    showDialogBox!!.cancel()
                }
            }
//            }
        }

        ivClose.setOnClickListener {
            showDialogBox!!.cancel()
            hideKeyboard(requireActivity())
        }

        showDialogBox!!.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(showDialogBox!!.getWindow()!!.getAttributes())
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER
        showDialogBox!!.getWindow()!!.setAttributes(lp)


    }



    fun setObserver() {

        viewModel.searchAutoFillResponseSuccess.observe(requireActivity(), Observer {

            Log.d("@@@@", "Success")

            Log.e("call", "list " + it!!.model.toString())

            if (it.message != "Success") {
//              showShortToast(it.message!!)
            } else {

                isAdapterClicked = false
                searchlist.clear()
                searchListItems.clear()
                searchlist.addAll(it!!.model)

                for (i in 0 until searchlist.size) {
                    searchListItems.add(searchlist.get(i).searchResult)
                }

                Log.e("call", "@@@ LIST SEARCH " + searchListItems)

                if (autoTextView.text.toString().equals("")) {
                    searchListItems.clear()
                    selectFromList = ""
                    rvSearchItems.visibility = View.GONE
                    searchItemAdapter.notifyDataSetChanged()
                } else {
                    if (searchListItems.size > 0) {
                        rvSearchItems.visibility = View.VISIBLE
                        rvSearchItems.layoutManager = LinearLayoutManager(activity)

                        searchItemAdapter = SearchItemAdapter(this@SearchFragment, searchlist)
                        rvSearchItems.adapter = searchItemAdapter
                    } else {
                        searchListItems.clear()
                        rvSearchItems.visibility = View.GONE
                        searchItemAdapter.notifyDataSetChanged()
                    }
                }

                listviewGreenButton()

                for (i in 0 until searchlist.size) {

                    if (it.model.get(i).type.equals("RLU")) {
                        commontype = "RLU"
                        common = it.model.get(i).searchResult
                    } else if (it.model.get(i).type.equals("County")) {
                        commontype = "County"
                        common = it.model.get(i).searchResult
                    } else if (it.model.get(i).type.equals("Region")) {
                        commontype = "Region"
                        common = it.model.get(i).searchResult
                    } else {
                        commontype = ""
                        common = it.model.get(i).searchResult
                    }

                    searchListItems.add(searchlist.get(i).searchResult)
                }

            }
        }
        )



        viewModel.searchResponseSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")

            Log.e("call", "list " + it!!.model.toString())

            if (it.message == "Success") {
//              showShortToast(it.message!!)
                listviewGreenButton()

                searchResponseList.clear()
                if (it.model.size <= 0) {
                    llResetfilterlayout.visibility = View.VISIBLE
                    gv_SearchListView.visibility = View.GONE
                    flMap.visibility = View.GONE
                } else {
                    llResetfilterlayout.visibility = View.GONE
                    gv_SearchListView.visibility = View.VISIBLE
                    flMap.visibility = View.GONE
                    searchResponseList.addAll(it.model)
                    /*for (i in 0 until searchResponseList.size) {
                        searchResponseList.add(it.model.get(i))
                    }*/
                    searchListViewGridAdapter.notifyDataSetChanged()
                }


            } else {
                showShortToast(it.message!!)
            }

        }
        )

        viewModel.getAvailableStatesResponseSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")

            Log.e("call", "list " + it!!.model.toString())

            if (it.message != "Success") {
//                showShortToast(it.message!!)
            } else {

                if (it.model.size <= 0) {
                    showAlert("No State Available")
                } else {

                    stateNameList.clear()
                    getAllAvailableStatesResponseList.clear()
                    getAllAvailableStatesResponseList.addAll(it.model)
                    for (i in 0 until getAllAvailableStatesResponseList.size) {
                        stateNameList.add(getAllAvailableStatesResponseList.get(i).stateName)
                    }

                    psSelectStateSearch?.setItems(stateNameList!!)

                    psSelectStateSearch.setOnSpinnerItemSelectedListener<String> { oldIndex, oldItem, newIndex, newItem ->

                        showDialogBox!!.dismiss()
                        // do something
                        statnamearray.clear()
                        statename = newItem
                        selectedCounty = ""
                        statnamelist = ArrayList<String>(Arrays.asList(statename))
                        listviewGreenButton()

                        var getAvailableCountiesByStateBody = GetAvailableCountiesByStateBody(
                            getAllAvailableStatesResponseList.get(newIndex).stateAbbrev
                        )
                        viewModel.getAvailableCountiesByStateRequest(
                            getAvailableCountiesByStateBody,
                            pref.getString(Constants.TOKEN)
                        )
                        psCountySpinner.clearSelectedItem()
                        getAvailableCountiesByStateResponseList.clear()

                        if (selectedCounty == null) {
                            selectedCounty = ""
                        }

                        if (statename == null) {
                            statename = ""
                        }

                        selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                        var fcomlist: List<String> =
                            ArrayList<String>(Arrays.asList(selectFromList))
                        statnamelist = ArrayList<String>(Arrays.asList(statename))

                        if (selectFromList != null) {
                            if (commontype == "RLU") {
                                priceSort(
                                    selectedCountylist,
                                    statnamelist,
                                    dummylist,
                                    dummylist,
                                    dummylist,
                                    fcomlist,
                                    "" + sort,
                                    "" + order
                                )
                            } else if (commontype == "County") {
                                priceSort(
                                    fcomlist, statnamelist, dummylist, dummylist, dummylist,
                                    dummylist, "" + sort, "" + order
                                )
                            } else if (commontype == "Region") {
                                priceSort(
                                    selectedCountylist,
                                    statnamelist,
                                    fcomlist,
                                    dummylist,
                                    dummylist,
                                    dummylist,
                                    "" + sort,
                                    "" + order
                                )
                            } else {
                                priceSort(
                                    selectedCountylist,
                                    statnamelist,
                                    dummylist,
                                    fcomlist,
                                    dummylist,
                                    dummylist,
                                    "" + sort,
                                    "" + order
                                )
                            }
                        } else {
                            if (selectFromList == null) {
                                selectFromList = ""
                                normal = autoTextView.text.toString()
                                var freetextlist: List<String> =
                                    ArrayList<String>(Arrays.asList(normal))
                                normal?.let { commonarray.add(it) }
                                priceSort(
                                    selectedCountylist,
                                    statnamelist,
                                    dummylist,
                                    dummylist,
                                    freetextlist,
                                    dummylist,
                                    "" + sort,
                                    "" + order
                                )
                            }
                        }





                    }
                }


//                showShortToast(it.message!!)
            }
        }
        )

        viewModel.getAvailableCountiesByStateResponseSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")

          //  Log.e("call", "list " + it!!.model.toString())

            if (it!!.model!=null){


            }else {
                countyNameList.clear()
                setDynamicHeightOnSpinner()
                psCountySpinner.setItems(countyNameList)

            }

            if (it.message != "Success") {
//                showShortToast(it.message!!)
            } else {
//                if (it.model.size<=0) {
//                    showAlert("No County available!")
//                } else {
                Log.e("call", "@@@ countyNameList:   " + countyNameList.toString())
                countyNameList.clear()
                getAvailableCountiesByStateResponseList.addAll(it.model)
                for (i in it.model.indices) {
                    countyNameList.add(it.model.get(i).countyName)
                }
                setDynamicHeightOnSpinner()
                psCountySpinner.setItems(countyNameList)

                psCountySpinner.setOnSpinnerItemSelectedListener<String> { oldIndex, oldItem, newIndex, newItem ->

                    showDialogBox!!.dismiss()
                    // do something
                    Log.e("call", "nicepsinee " + newItem)
                    listviewGreenButton()

                    selectedCounty = newItem
                    selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
                    if (selectedCounty == null) {
                        selectedCounty = ""
                    }

                    if (statename == null) {
                        statename = ""
                    }

                    var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
                    statnamelist = ArrayList<String>(Arrays.asList(statename))

                    if (selectFromList != null) {
                        if (commontype == "RLU") {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                                fcomlist, "" + sort, "" + order
                            )
                        } else if (commontype == "County") {
                            priceSort(
                                fcomlist, statnamelist, dummylist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else if (commontype == "Region") {
                            priceSort(
                                selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        } else {
                            priceSort(
                                selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                                dummylist, "" + sort, "" + order
                            )
                        }
                    } else {
                        if (selectFromList == null) {
                            selectFromList = ""
                            normal = autoTextView.text.toString()
                            var freetextlist: List<String> =
                                ArrayList<String>(Arrays.asList(normal))
                            normal?.let { commonarray.add(it) }
                            priceSort(
                                selectedCountylist,
                                statnamelist,
                                dummylist,
                                dummylist,
                                freetextlist,
                                dummylist,
                                "" + sort,
                                "" + order
                            )
                        }
                    }

                }

            }

//                showShortToast(it.message!!)

        }
        )

        viewModel.postSaveSearchesResponse.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")
            Log.e("call", "list " + it!!.model.toString())
            if (it.message != "Success") {
//                showShortToast(it.message!!)
            } else {
//                showShortToast(it.message!!)
                showDialog("your search is saved")
            }
        }
        )

        viewModel.getAllAmenitiesResponseSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")

            Log.e("call", "list " + it!!.model.toString())

            for (i in 0 until it!!.model.size) {
                if (it!!.model.get(i).amenityType.equals("Activity")) {
                    amenitylist1.add(it.model.get(i))
                } else if (it!!.model.get(i).amenityType.equals("Amenity")) {
                    amenitylist2.add(it.model.get(i))
                }
            }

        }
        )

        viewModel.apiError.observe(requireActivity(), Observer {
            Log.d("@@@@", "Api error Failed" + it.toString())
        //    showShortToast(it)
        }
        )

        viewModel.isLoading.observe(requireActivity(), Observer {
            Log.d("@@@@", "loading")
            if (it) {
                progressBarPB.show()
            } else {
                progressBarPB.dismiss()
            }
        })

    }


    override fun onClick(index: Int) {

        selectActivitiesAdapter.notifyDataSetChanged()

    }

    override fun onAmenityClick(index: Int) {

        selectAmenitiesAdapter.notifyDataSetChanged()

    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        when (view?.id) {

        }
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {

    }

     fun searchClickItem(text: String, type: String) {

        commontype = type
        isAdapterClicked = true
        autoTextView.setText(text)
        selectFromList = autoTextView.text.toString()
        rvSearchItems.visibility = View.GONE
        listviewGreenButton()

        if (selectedCounty == null) {
            selectedCounty = ""
        }

        if (statename == null) {
            statename = ""
        }

        selectedCountylist = ArrayList<String>(Arrays.asList(selectedCounty))
        var fcomlist: List<String> = ArrayList<String>(Arrays.asList(selectFromList))
        statnamelist = ArrayList<String>(Arrays.asList(statename))

        if (selectFromList != null) {

            if (commontype == "RLU") {
                priceSort(
                    selectedCountylist, statnamelist, dummylist, dummylist, dummylist,
                    fcomlist, "" + sort, "" + order
                )
            } else if (commontype == "County") {
                priceSort(
                    fcomlist, statnamelist, dummylist, dummylist, dummylist,
                    dummylist, "" + sort, "" + order
                )
            } else if (commontype == "Region") {
                priceSort(
                    selectedCountylist, statnamelist, fcomlist, dummylist, dummylist,
                    dummylist, "" + sort, "" + order
                )
            } else {
                priceSort(
                    selectedCountylist, statnamelist, dummylist, fcomlist, dummylist,
                    dummylist, "" + sort, "" + order
                )
            }
        } else {
            if (selectFromList == null) {
                selectFromList = ""
                normal = autoTextView.text.toString()
//                      freetextcommon = normal
                var freetextlist: List<String> = ArrayList<String>(Arrays.asList(normal))
                normal?.let { commonarray.add(it) }
                priceSort(
                    selectedCountylist,
                    statnamelist,
                    dummylist,
                    dummylist,
                    freetextlist,
                    dummylist,
                    "" + sort,
                    "" + order
                )
            }
        }


    }

    override fun onGridClick(index: Int) {

        var publickey = searchResponseList.get(index).rluPropertyModel.publicKey
        bundle.putString("publickey", publickey)
        Log.e("call", "publickey Active " + publickey)
        val fragment = LicenceFragment()
        val bundle = Bundle()
        bundle.putString("publickey", publickey)
        fragment.setArguments(bundle)
        addNewFragment(fragment, R.id.container, true)

        PreApprovalRequestFragment.isBackPreApproval = false
    }


    fun setDynamicHeightOnSpinner() {
        if (countyNameList.size == 1) {
            psCountySpinner.spinnerPopupHeight =
                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._35sdp)
        } else if (countyNameList.size == 2) {
            psCountySpinner.spinnerPopupHeight =
                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._70sdp)
        } else if (countyNameList.size == 3) {
            psCountySpinner.spinnerPopupHeight =
                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._105sdp)
        }
//        else if (countyNameList.size == 4) {
//            psCountySpinner.spinnerPopupHeight =
//                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._140sdp)
//        } else if (countyNameList.size == 5) {
//            psCountySpinner.spinnerPopupHeight =
//                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._175sdp)
//        } else if (countyNameList.size == 6) {
//            psCountySpinner.spinnerPopupHeight =
//                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._210sdp)
//        } else if (countyNameList.size == 7) {
//            psCountySpinner.spinnerPopupHeight =
//                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._245sdp)
//        } else if (countyNameList.size == 8) {
//            psCountySpinner.spinnerPopupHeight =
//                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._280sdp)
//        }
//        else {
//            psCountySpinner.spinnerPopupHeight =
//                resources.getDimensionPixelSize(com.intuit.sdp.R.dimen._315sdp)
//        }
    }

    override fun onMapReady(googleMap: GoogleMap) {

        googleMap.getUiSettings().setZoomGesturesEnabled(true);
        googleMap.getUiSettings().isScrollGesturesEnabled = false



    }

}

