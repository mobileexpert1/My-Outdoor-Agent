package com.myoutdoor.agent.fragment.sociallogin

import android.app.Activity.RESULT_CANCELED
import android.app.Application
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.CompoundButton
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.facebook.*
import com.facebook.appevents.AppEventsLogger
import com.facebook.login.LoginResult
import com.google.android.gms.auth.api.Auth
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.GoogleApiClient
import com.myoutdoor.agent.R
import com.myoutdoor.agent.activities.MainActivity
import com.myoutdoor.agent.activities.loginsignup.LoginSignUpActivity
import com.myoutdoor.agent.activities.loginsignup.LoginSignUpActivity.Companion.loginSignUpActivity
import com.myoutdoor.agent.activities.loginsignup.LoginSignUpViewModel
import com.myoutdoor.agent.fragment.forgotpassword.ForgotPasswordFragment
import com.myoutdoor.agent.models.register.LoginBody
import com.myoutdoor.agent.models.sociallogin.SocailLoginBody
import com.myoutdoor.agent.utils.*
import kotlinx.android.synthetic.main.fragment_login.*
import org.json.JSONObject


class LoginFragment : BaseFragment(), GoogleApiClient.OnConnectionFailedListener {

    lateinit var viewModel: LoginSignUpViewModel
    lateinit var pref: SharedPref
    lateinit var spref: ShrdPreferences

    var signInButton: SignInButton? = null
//    private var googleApiClient: GoogleApiClient? = null
    private val RC_SIGN_IN = 1
    var check:Boolean = false

    private var loginPreferences: SharedPreferences? = null
    private var loginPrefsEditor: SharedPreferences.Editor? = null
    private var saveLogin: Boolean? = null


    var callbackManager: CallbackManager?=null
    private val EMAIL = "email"

    lateinit var loginuser: String
    lateinit var userName: String
    lateinit var userAccountID: String
    lateinit var token: String
    lateinit var authtoken: String
    var passwordvisible = false


    override fun getLayoutId(): Int {
        return R.layout.fragment_login
    }

    override fun onCreateView() {



        pref= SharedPref(requireContext())
        spref= ShrdPreferences(requireContext())
        FacebookSdk.sdkInitialize(requireContext())
        AppEventsLogger.activateApp(application = Application())
        viewModel = ViewModelProvider(this).get(LoginSignUpViewModel::class.java)


        tvLoginForgotPassword.setOnClickListener {
            addNewFragment(ForgotPasswordFragment(), R.id.mainContainerForgotPassword, true)
        }

//        hintRemover(etPasswordLayout, edtLoginEnterpassword, R.string.password.toString())
        var email=edtLoginEnterEmail.text.toString()
        var password=edtLoginEnterpassword.text.toString()

/*        edtLoginEnterpassword.setOnFocusChangeListener { _, hasFocus ->
            etPasswordLayout.hint = if (hasFocus) {
                ""
            } else {

                if (edtLoginEnterpassword.text!!.isEmpty()){
                    getString(R.string.password)
                }
                ""
            }
        }*/

       edtLoginEnterpassword.setOnFocusChangeListener { _, hasFocus ->
          // etPasswordLayout.setHintAnimationEnabled(false)
           edtLoginEnterpassword.setOnFocusChangeListener(null)
        }


//        cbAgreeterms.setOnCheckedChangeListener(object : CompoundButton.OnCheckedChangeListener {
//
//            override fun onCheckedChanged(p0: CompoundButton?, p1: Boolean) {
//                if (p0!!.isChecked) {
//                    check=true
//                    spref.setBoolean(Constants.IS_CHECKED,check)
//                    spref.setString(Constants.EMAIL,edtLoginEnterEmail.text.toString())
//                    spref.setString(Constants.PASSWORD,edtLoginEnterpassword.text.toString())
//                    Log.e("EMAIL","EMAI..       "      +email);
//                    Log.e("PASSWORD","PASSWORD..     "+password)
//                    Log.e("EMAIL","EMAI....isChecked.."+pref.getString(Constants.EMAIL))
//                    Log.e("PASSWORD","PASSWORD....isChecked."+pref.getString(Constants.PASSWORD))
//                }
//                else {
//                    check=false
//                    spref.setBoolean(Constants.IS_CHECKED,check)
//                    spref.setString(Constants.EMAIL,"")
//                    spref.setString(Constants.PASSWORD,"")
//                }
//            }
//        })



        if (spref.getBoolean(Constants.IS_CHECKED)==true){
            Log.e("EMAIL","EMAI......"+spref.getString(Constants.EMAIL))
            Log.e("PASSWORD","PASSWORD....."+spref.getString(Constants.PASSWORD))
            edtLoginEnterEmail.setText(spref.getString(Constants.EMAIL))
            edtLoginEnterpassword.setText(spref.getString(Constants.PASSWORD))
            cbAgreeterms.isChecked=true
        }else{
            edtLoginEnterEmail.setText("")
            edtLoginEnterpassword.setText("")
            cbAgreeterms.isChecked=false
        }



       /* if (pref.getBoolean(Constants.IS_CHECKED)==true){
            cbAgreeterms.isChecked=true
        }else{
            cbAgreeterms.isChecked=false
        }*/


        tvLoginmain.setOnClickListener {

            if (edtLoginEnterEmail.text.isEmpty()) {
                showShortToast("Please enter email.")
            } else if (!isEmailValid(edtLoginEnterEmail.text.toString())) {
                showShortToast("Please enter valid email.")
            } else if (edtLoginEnterpassword.text!!.isEmpty()) {
                showShortToast("Please enter password.")
            } /*else if (!isValidPassword(edtLoginEnterpassword.text.toString())) {
                showShortToast("Please enter valid password.")
            }*/ else {
                val loginBody = LoginBody(
                    edtLoginEnterEmail.text.toString(),
                    edtLoginEnterpassword.text.toString(),
                    "orbis",
                    ""
                )
                viewModel.loginRequest(loginBody)

//                if (spref.getBoolean(Constants.IS_CHECKED)==true){
//                    Log.e("EMAIL","EMAI......"+spref.getString(Constants.EMAIL))
//                    Log.e("PASSWORD","PASSWORD....."+spref.getString(Constants.PASSWORD))
//                    edtLoginEnterEmail.setText(spref.getString(Constants.EMAIL))
//                    edtLoginEnterpassword.setText(spref.getString(Constants.PASSWORD))
//                    cbAgreeterms.isChecked=true
//                }else{
//                    edtLoginEnterEmail.setText("")
//                    edtLoginEnterpassword.setText("")
//                    cbAgreeterms.isChecked=false
//                    spref
//                }

            }
        }

// google login


        ivGooglelogin!!.setOnClickListener {


            val intent = Auth.GoogleSignInApi.getSignInIntent(loginSignUpActivity.googleApiClient!!)
            startActivityForResult(intent, RC_SIGN_IN)
        }

        facebookloginBT.setReadPermissions("email", "public_profile")
        //facebook login
        facebookloginBT.setBackgroundResource(R.drawable.ic_facebook__1)

        facebookloginBT.setOnClickListener {

//            facebookloginBT.setReadPermissions(listOf(EMAIL))
            callbackManager = CallbackManager.Factory.create()
            // If you are using in a fragment, call loginButton.setFragment(this);
            // Callback registration
            // If you are using in a fragment, call loginButton.setFragment(this);
            // Callback registration
            facebookloginBT.registerCallback(callbackManager, object :
                FacebookCallback<LoginResult?> {
                override fun onSuccess(loginResult: LoginResult?) {
                    Log.d("MainActivity", "Facebook token: " + loginResult!!.accessToken.token)

                    // login succes


                    // App code
                    // App code
                    val request = GraphRequest.newMeRequest(
                        loginResult.accessToken,
                        object : GraphRequest.GraphJSONObjectCallback {
                            override   fun onCompleted(`object`: JSONObject?, response: GraphResponse?) {
                                Log.e("LoginActivity", response.toString())

                                // Application code
                                val id = `object`!!.getString("id")
                                val name = `object`!!.getString("name")
                                val email = `object`!!.getString("email")

                                Log.e("call","name "+name)
                                Log.e("call","email "+email)
                                Log.e("call","id " +id)

                                /// hit api signup
                                val signupBody= SocailLoginBody(
                                    0,""+id,"facebook",""+id,
                                    "",""+email,""+name,false,"",false,
                                    "","",0,"","","")

                                viewModel.signupRequest(signupBody)

                            }
                        })
                    val parameters = Bundle()
                    parameters.putString("fields", "id,name,email,gender,birthday")
                    request.parameters = parameters
                    request.executeAsync()


                    /*   startActivity(
                        Intent(
                            requireContext(),
                            CustomTabActivity::class.java
                        )
                    )*/// App code
                }

                override fun onCancel() { // App code
                }
                override fun onError(exception: FacebookException) { // App code
                Log.e("FaceBook Error",exception.message.toString())

                }
            })
            /*callbackManager = CallbackManager.Factory.create()
            with(LoginManager) {
                getInstance().registerCallback(callbackManager,
                        object : FacebookCallback<LoginResult?> {
                            override fun onSuccess(loginResult: LoginResult?) {
                            // App code
                            }
                            override fun onCancel() { // App code
                            }
                            override fun onError(exception: FacebookException) { // App code
                            }
                            val accessToken = AccessToken.getCurrentAccessToken()
                             accessToken!= null && !accessToken.isExpired
                        })
            }*/
        }
        setObserver()



        passwordEyeImv.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                if (!passwordvisible) {
                    edtLoginEnterpassword.setTransformationMethod(PasswordTransformationMethod.getInstance())
                    passwordvisible = true
                    edtLoginEnterpassword.setSelection(edtLoginEnterpassword.getText().length)
                    passwordEyeImv.setImageResource(R.drawable.ic_hide__1_)
                } else {
                    edtLoginEnterpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance())
                    passwordvisible = false
                    edtLoginEnterpassword.setSelection(edtLoginEnterpassword.getText().length)
                    passwordEyeImv.setImageResource(R.drawable.ic_show_1)
                }
            }
        })

    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode != RESULT_CANCELED){
            if (requestCode === RC_SIGN_IN) {
                val result = Auth.GoogleSignInApi.getSignInResultFromIntent(data!!)
                Log.e("call","result "+result.toString())
                var acct: GoogleSignInAccount = (if (result != null) result.signInAccount else throw NullPointerException("Expression 'result' must not be null"))!!
                var userName = acct.displayName
                var userEmail = acct.email
                var authid = acct.id
                Log.e("userName", userName.toString()+"userEmail"+userEmail.toString())

                ////  hit api signup

                val signupBody= SocailLoginBody(
                    0,""+authid,"google",""+authid,
                    "",""+userEmail,""+userName,false,"",false,
                    "","",0,"","","")

                viewModel.signupRequest(signupBody)

//                val loginBody = LoginBody(
//                    userEmail.toString(),
//                    "",
//                    "Google",
//                    authid.toString()
//                )
//                viewModel.loginRequest(loginBody)
            }
            callbackManager?.onActivityResult(requestCode, resultCode, data)
        }

        callbackManager?.onActivityResult(requestCode, resultCode, data)

    }

    fun setObserver() {

        viewModel.loginSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")
            // check for unactivated account
            if (it.message!="Success"){
//                showShortToast(it.message!!)
                if (it!!.model!=null){

                }else {
                    showShortToast(it!!.message.toString())
                }
            }
            else {
                showShortToast("Login Successfully")
                loginuser=it.model.toString()
                userName= it.model!!.name
                userAccountID= it.model!!.userAccountID
                pref.setString(Constants.USER_NAME,userName)
                pref.setString(Constants.USER_EMAIL,it.model!!.email)
                pref.setString(Constants.userAccountID,userAccountID)
                pref.setString(Constants.IS_FROM_LOGIN,"true")
                token=it.model!!.authToken
                authtoken=it.model!!.authToken
                pref.setString(Constants.TOKEN,token)
                pref.setString(Constants.AUTH_TOKEN,token)

                val intent = Intent(requireActivity(), MainActivity::class.java)
                SessionData.I().makeIntentClearHistory(intent)
                startActivity(intent)


                if (cbAgreeterms.isChecked){
                    check=true
                    spref.setBoolean(Constants.IS_CHECKED,check)
                    spref.setString(Constants.EMAIL,edtLoginEnterEmail.text.toString())
                    spref.setString(Constants.PASSWORD,edtLoginEnterpassword.text.toString())
                }else {
                    check=false
                    spref.setBoolean(Constants.IS_CHECKED,check)
                    spref.setString(Constants.EMAIL,"")
                    spref.setString(Constants.PASSWORD,"")
                }


            }
        }
        )

        viewModel.signupResponseSuccess.observe(requireActivity(), Observer {
            // check for unactivated account
            if (it.message!="Success"){
                showShortToast(it.message!!)
            }
            else {

                try {
                    loginuser=it.model.toString()
                    userName= it.model.firstName
                    userAccountID= it.model.userAccountID
                    token=it.model.authToken
                    token=it.model.authToken

                    pref.setString(Constants.USER_NAME,userName)
                    pref.setString(Constants.userAccountID,userAccountID)
                    pref.setString(Constants.IS_FROM_LOGIN,loginuser)
                    pref.setString(Constants.TOKEN,token)
                    pref.setString(Constants.TOKEN,token)

                    val intent2 = Intent(requireActivity(), MainActivity::class.java)
                    SessionData.I().makeIntentClearHistory(intent2)
                    startActivity(intent2)

                }catch (e:Exception){
                    Log.e("call","exp1213 "+e.toString())
                }

                //  Log.d("@@@@", "Success")


//                Log.e("call","@@@@ loginuser "+loginuser)
//                Log.e("call","@@@@ username "+userName)
//                Log.e("call","@@@@ userAccountID "+userAccountID)
//                Log.e("call","@@@@ token "+token)


            }
        }
        )

        viewModel.apiError.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed "+it!!.toString())
//            showShortToast(it)
        }
        )

        viewModel.apiLoginError.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed "+it!!.toString())
            showShortToast(it)
        }
        )

        viewModel.isLoading.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed")
            if (it) {
                progressBarPB.show()
            }
            else {
                progressBarPB.dismiss()
            }
        }
        )

    }

    override fun onConnectionFailed(p0: ConnectionResult) {

    }

}

