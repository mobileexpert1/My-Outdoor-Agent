package com.myoutdoor.agent.models.search

data class RluImage(
    var caption: String,
    var imageFileName: String,
    var productID: Int,
    var productImageID: Int
)