package com.myoutdoor.agent.models.changepassword

data class ChangePasswordBody(
    var Password: String,
    var NewPassword: String
)