package com.myoutdoor.agent.models.licensedetails.forhome

data class SpecialCondition(
    var productID: Int,
    var specCndDesc: String,
    var specCndID: Int
)