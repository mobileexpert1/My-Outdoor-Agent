package com.myoutdoor.agent.models.addupdatevehicle

data class Model(
    var licenseContractId: Int,
    var vehicleColor: String,
    var vehicleDetailID: Int,
    var vehicleLicensePlate: String,
    var vehicleMake: String,
    var vehicleModel: String,
    var vehicleState: String,
    var vehicleType: Any
)