package com.myoutdoor.agent.fragment.licence.model

data class SpecialCondition(
    var productID: Int,
    var specCndDesc: String,
    var specCndID: Int
)