package com.myoutdoor.agent.fragment.licence

import android.Manifest
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.github.barteksc.pdfviewer.PDFView
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.myoutdoor.agent.R
import com.myoutdoor.agent.activities.MainActivity
import com.myoutdoor.agent.adapter.LicenseGuideLineHomeAdapter
import com.myoutdoor.agent.adapter.LicenseNowAmenityAdapter
import com.myoutdoor.agent.adapter.SimilarPropertiesAdapter
import com.myoutdoor.agent.adapter.ViewPagerAdapter
import com.myoutdoor.agent.fragment.PreApprovalRequest.PreApprovalRequestFragment
import com.myoutdoor.agent.fragment.licence.model.Amenity
import com.myoutdoor.agent.fragment.licence.model.LicenceKeyBody
import com.myoutdoor.agent.fragment.licence.model.SimilarProperty
import com.myoutdoor.agent.fragment.licence.model.SpecialCondition
import com.myoutdoor.agent.fragment.message_new.model.send_messages.SendMessageRequest
import com.myoutdoor.agent.models.DayPassAvailibility.DayPassRequest
import com.myoutdoor.agent.models.getPaymentToken.GetPaymentTokenBody
import com.myoutdoor.agent.models.preapprovalrequest.cancelrequest.PreApprovalCancelRequestBody
import com.myoutdoor.agent.models.preapprovalrequest.request.PreApprovalRequest
import com.myoutdoor.agent.models.rightofentry.RightOfEntryBody
import com.myoutdoor.agent.utils.BaseFragment
import com.myoutdoor.agent.utils.Constants
import com.myoutdoor.agent.utils.SharedPref
import com.prolificinteractive.materialcalendarview.CalendarDay
import com.prolificinteractive.materialcalendarview.DayViewDecorator
import com.prolificinteractive.materialcalendarview.DayViewFacade
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener
import kotlinx.android.synthetic.main.calender_date_proceed_pop_up.*
import kotlinx.android.synthetic.main.calender_pop_up.*
import kotlinx.android.synthetic.main.fragment_licence.*
import kotlinx.android.synthetic.main.fragment_licence_now.SliderDots
import kotlinx.android.synthetic.main.fragment_licence_now.ivBackpress
import kotlinx.android.synthetic.main.fragment_licence_now.rvActivitiesLN
import kotlinx.android.synthetic.main.fragment_licence_now.rvAmenitiesLN
import kotlinx.android.synthetic.main.fragment_licence_now.rvSimilarPropertiesHV
import kotlinx.android.synthetic.main.fragment_licence_now.tvAcres
import kotlinx.android.synthetic.main.fragment_licence_now.tvAddress
import kotlinx.android.synthetic.main.fragment_licence_now.tvContactPAgent
import kotlinx.android.synthetic.main.fragment_licence_now.tvHplNorthDesc
import kotlinx.android.synthetic.main.fragment_licence_now.tvHplNorthPrice
import kotlinx.android.synthetic.main.fragment_licence_now.tvLicenceEndDateDec
import kotlinx.android.synthetic.main.fragment_licence_now.tvLicenceStartDateDesc
import kotlinx.android.synthetic.main.fragment_licence_now.tvNoActivityAvailable
import kotlinx.android.synthetic.main.fragment_licence_now.tvNoAmenityAvailableHome
import kotlinx.android.synthetic.main.fragment_licence_now.tvPriceDec
import kotlinx.android.synthetic.main.fragment_licence_now.tvPropertyDescription
import kotlinx.android.synthetic.main.fragment_licence_now.tvPropertyID
import kotlinx.android.synthetic.main.fragment_licence_now.tvRequestTempAccess
import kotlinx.android.synthetic.main.fragment_licence_now.tvSimilarProperties
import kotlinx.android.synthetic.main.fragment_licence_now.tvSpecialConditions
import kotlinx.android.synthetic.main.fragment_licence_now.tvTime
import kotlinx.android.synthetic.main.fragment_licence_now.viewPager
import kotlinx.android.synthetic.main.fragment_message.*
import kotlinx.android.synthetic.main.leave_us_message_box.*
import kotlinx.android.synthetic.main.leave_us_message_box.tvCancelMessage
import kotlinx.android.synthetic.main.leave_us_message_box.tvSubmitMessage
import kotlinx.android.synthetic.main.popup_show_response.*
import kotlinx.android.synthetic.main.pre_approval_request_popup.*
import java.io.BufferedInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import javax.net.ssl.HttpsURLConnection


class LicenceFragment : BaseFragment(), SimilarPropertiesAdapter.OnItemClickListener ,
    OnMapReadyCallback {


    var list1 = ArrayList<Amenity>()
    var list2 = ArrayList<Amenity>()
    //  var list3 = ArrayList<SpecialCondition>()
    var list3 = ArrayList<SpecialCondition>()
    var data = ArrayList<SimilarProperty>()
    lateinit var viewModel: LicenceViewModel
    private var dotscount = 0
    val bundle = Bundle()
    var builder2: AlertDialog.Builder? = null
    var key: String = ""
    lateinit var productID: String


    var productTypeID: Int = 0
    var prodID: Int = 0
    var agreementName: String = ""
    lateinit var rluNo: String
    var clientInvoiceId: Int = 0
    var accountId: Int = 0
    var licenceFee: Double? = null
    lateinit var preApprRequestID: String
    var isUserProfileComplete: Boolean = false

    var showDialogBox: Dialog? = null
    lateinit var pref: SharedPref
    var cal = Calendar.getInstance()

    var lastDaySelect: Int = 0


    override fun getLayoutId(): Int {
        return R.layout.fragment_licence
    }

    override fun onCreateView() {
        showDialogBox = Dialog(requireContext())

        val bundle = this.arguments
        if (bundle != null) {
            key = bundle.getString("publickey")!!
            Log.e("call", "key " + key)
        }
        pref = SharedPref(requireContext())


        viewModel = ViewModelProvider(this).get(LicenceViewModel::class.java)
        setObserver()

        ivBackpress.setOnClickListener {
            requireActivity().onBackPressed()
            MainActivity.mainActivity.bottomNav.visibility = View.VISIBLE
            if (PreApprovalRequestFragment.isBackPreApproval){
                PreApprovalRequestFragment.preApprovalRequestFragment.refreshApi()
            }
        }
        backPress_RefreshAPi()


        var licenceKeyBody = LicenceKeyBody(
            "" + key
        )
        Log.e("call", "publickey " + key)
        viewModel.licenceDetails(licenceKeyBody, pref.getString(Constants.TOKEN))

        /*   webView1.webViewClient = WebViewClient()
           webView1.settings.javaScriptEnabled = true
   //        webView1.loadUrl("https://www.google.com/maps/")
           webView1.loadUrl("https://www.google.com/maps/@29.1280178,103.5976885,3z")*/



        val mapFragment =requireActivity().supportFragmentManager.findFragmentById(R.id.map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)

        checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, 1);


     //   fragmentBackPressHandle()

        tvRequestTempAccess.setOnClickListener {
            requestAccessPopup()
        }

        tvLicenceNow.setOnClickListener {


            if (tvLicenceNow.text.toString().contains("Select")){
                if (isUserProfileComplete==true){

                    if (tvDayPass.getVisibility() == View.VISIBLE) {
                        calenderPopUp()
                    }else {
                        acceptAndPayPopup(agreementName)
                    }

                    //   acceptAndPayPopup(agreementName)
                }else{
                    showAlert("Incomplete profile. Phone number and mailing address are required for purchasing.")
                }
            }else if(tvLicenceNow.text.toString().contains("Cancel Request")){
                showAddDeleteDialog()
            }else if(tvLicenceNow.text.toString().contains("Request Pre-Approval")){

                showPreApprovalRequestDialog()

            }
        }

      //  fragmentBackPressHandle()
    }


    fun backPress_RefreshAPi() {
        requireView().isFocusableInTouchMode = true
        requireView().requestFocus()
        requireView().setOnKeyListener(View.OnKeyListener { v, keyCode, event ->
            if (event.action === KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                requireActivity().onBackPressed()
                MainActivity.mainActivity.bottomNav.visibility = View.VISIBLE

                if (PreApprovalRequestFragment.isBackPreApproval){
                    PreApprovalRequestFragment.preApprovalRequestFragment.refreshApi()
                }

                return@OnKeyListener true
            }
            false
        })
    }

    fun showAddDeleteDialog() {
        builder = AlertDialog.Builder(requireActivity())
        builder?.setTitle("Cancel Your Request")
        builder?.setMessage("Do you want to cancel your request for " + tvHplNorthDesc.text.toString()+"?")
            ?.setCancelable(false)
            ?.setPositiveButton("YES", DialogInterface.OnClickListener { dialog, id ->
                removeitem(preApprRequestID)
                dialog.dismiss()
            })
            ?.setNegativeButton("NO", DialogInterface.OnClickListener { dialog, id ->
                dialog.cancel()
            })
        val alert: AlertDialog = builder!!.create()
        alert.setOnShowListener(DialogInterface.OnShowListener {
            alert.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(requireActivity().getResources().getColor(R.color.green))
            alert.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(requireActivity().getResources().getColor(R.color.property_text_grey))
        })

        alert.show()
    }

    fun showPreApprovalRequestDialog(){
        showDialogBox!!.setContentView(R.layout.pre_approval_request_popup)
        showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
        showDialogBox!!.setCanceledOnTouchOutside(true)

        showDialogBox!!.etMessage.setText(""+pref.getString(Constants.USER_NAME)+" is requesting Pre-Approval.")

        showDialogBox!!.tvSubmitMessage.setOnClickListener {

            if (showDialogBox!!.etMessage.text.toString().equals("")){
                showShortToast("Please enter comments")
            }else {
                // hit api request

                Log.e("call","user account id:  "+pref.getString(Constants.userAccountID))
                Log.e("call","clientInvoiceId:  "+clientInvoiceId)
                Log.e("call","productID:  "+productID)

                val preApprovalRequest = PreApprovalRequest(clientInvoiceId.toString(), productID , showDialogBox!!.tvSubmitMessage.text.toString(), pref.getString(Constants.userAccountID))
                viewModel.preapprovalrequestv2(preApprovalRequest, pref.getString(Constants.TOKEN))

            }

        }

        showDialogBox!!.tvCancelMessage.setOnClickListener {
            showDialogBox!!.hide()
        }
        showDialogBox!!.show()
    }



    fun checkPermission(permission: String, requestCode: Int) {
        if (ContextCompat.checkSelfPermission(
                requireActivity(),
                permission
            ) == PackageManager.PERMISSION_DENIED
        ) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(permission), requestCode)
        } else {

        }
    }


    private fun calenderPopUp() {

        showDialogBox!!.setContentView(R.layout.calender_pop_up)
        showDialogBox!!.setCanceledOnTouchOutside(true)
        showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
//        val layoutManager = LinearLayoutManager(requireContext())
//        layoutManager.orientation = LinearLayoutManager.VERTICAL

        val lp = WindowManager.LayoutParams()
        lp.copyFrom(showDialogBox!!.getWindow()!!.getAttributes())
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        showDialogBox!!.getWindow()!!.setAttributes(lp)
        showDialogBox!!.show()

        // calender functionality

        //calendarView.setSelectionMode(MaterialCalendarView.SELECTION_MODE_NONE);
        showDialogBox!!.calendarView.setDateSelected(CalendarDay.today(), true);
        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
        lastDaySelect = showDialogBox!!.calendarView.selectedDate!!.day

        showDialogBox!!.calendarView.setOnDateChangedListener(OnDateSelectedListener { widget, date, selected ->

            if (selected){

                var lastDayOfMonth = getLastDayOf(showDialogBox!!.calendarView!!.selectedDate!!.month-2,showDialogBox!!.calendarView!!.selectedDate!!.year - 1)

                Log.e("@@@","CHECK LAST MONTH DAY  "+lastDayOfMonth)

                try {

                    Log.e("call","date "+date.day)
                    Log.e("call","dateeeee "+showDialogBox!!.calendarView.selectedDates.get(0).day)

                    if (showDialogBox!!.calendarView.selectedDates.size == 1){

                        val calender: Calendar = Calendar.getInstance()
                        calender.add(Calendar.DATE, 1);
                        var day = showDialogBox!!.calendarView!!.selectedDate!!.day
                        val month =  showDialogBox!!.calendarView.selectedDate!!.month
                        val year =  showDialogBox!!.calendarView.selectedDate!!.year
                        showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), true);
                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)

                        lastDaySelect = showDialogBox!!.calendarView.selectedDate!!.day

                    }

                    else if (date.day == 1 && lastDaySelect == lastDayOfMonth ) {
                        val calender: Calendar = Calendar.getInstance()
                        calender.add(Calendar.DATE, 1);
                        var day = showDialogBox!!.calendarView!!.selectedDate!!.day
                        val month =  showDialogBox!!.calendarView.selectedDate!!.month
                        val year =  showDialogBox!!.calendarView.selectedDate!!.year
                        showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), true);

                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                        lastDaySelect = showDialogBox!!.calendarView.selectedDate!!.day
                    }
                    else {
                        if (date.day == lastDaySelect+1){
                            val calender: Calendar = Calendar.getInstance()
                            calender.add(Calendar.DATE, 1);
                            var day = date.day
                            val month =  showDialogBox!!.calendarView.selectedDate!!.month
                            val year =  showDialogBox!!.calendarView.selectedDate!!.year
                            showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), true);

                            showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)

                            lastDaySelect = showDialogBox!!.calendarView.selectedDate!!.day
                        }else {

                            var day = date.day
                            val month =  date.month
                            val year =  date.year
                            showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), false);
                            lastDaySelect = showDialogBox!!.calendarView.selectedDates.get(showDialogBox!!.calendarView.selectedDates.size - 1).day
                        }
                    }

                }

                catch (e:java.lang.Exception){
                    Log.e("call","exception: "+e.toString())
                }


            }
            else{
                /// select false case

             //   Log.e("call","CALENDER VIEW SIZE: "+showDialogBox!!.calendarView.selectedDates.size)

           //     Log.e("call","isSelected:-- "+selected)

//                Log.e("call","DAY: "+date.day)
//                Log.e("call","FIRST DAY: "+showDialogBox!!.calendarView.selectedDates.get(0).day)
//                Log.e("call","LAST DAY: "+showDialogBox!!.calendarView.selectedDates.get(showDialogBox!!.calendarView.selectedDates.size-1).day)


                if (showDialogBox!!.calendarView.selectedDates.size == 0){
                    var day = date.day
                    val month = date.month
                    val year =  date.year
                    showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), false);
                    showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                }
                else if (showDialogBox!!.calendarView.selectedDates.size >= 2){

                    if (date.day == showDialogBox!!.calendarView.selectedDates.get(showDialogBox!!.calendarView.selectedDates.size-1).day+1){
                        var day = date.day
                        val month = date.month
                        val year =  date.year
                        showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), false);
                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                    }
                    else if (date.day+1 == showDialogBox!!.calendarView.selectedDates.get(0).day){
                        var day = date.day
                        val month = date.month
                        val year =  date.year
                        showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), false);
                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                    }else {
                        var day = date.day
                        val month = date.month
                        val year =  date.year
                        showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), true);
                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                    }
                }
                else {
                    var day = date.day
                    val month = date.month
                    val year =  date.year
                    showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), false);
                    showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                }

            }

        })

        showDialogBox!!.calendarView.addDecorator(PrimeDayDisableDecorator())

        // plus button
        showDialogBox!!.llPlus.setOnClickListener {


            try {

                if (showDialogBox!!.calendarView.selectedDates.size > 0){
                    Log.e("call","@@@!23  "+showDialogBox!!.calendarView!!.selectedDate!!.day)

                    ////  go to next
                    var month_ = showDialogBox!!.calendarView.selectedDate!!.month - 1
                    var lastDayOfMonth = getLastDayOf(month_,showDialogBox!!.calendarView!!.selectedDate!!.year)

                    if (lastDayOfMonth == showDialogBox!!.calendarView.selectedDate!!.day){
                        showDialogBox!!.calendarView.goToNext()

//                        Log.e("call","@@@!DAY  "+showDialogBox!!.calendarView!!.selectedDate!!.day)
//                        Log.e("call","@@@!MONTH  "+CalendarDay.today().month)
//                        Log.e("call","@@@!MONTH  "+showDialogBox!!.calendarView.selectedDate!!.month)
//                        Log.e("call","@@@!YEAR  "+CalendarDay.today().year)
//                        Log.e("call","@@@!YEAR  "+calendarView.selectedDate!!.year)
//                        Log.e("call","@@@!YEAR  "+calendarView.selectedDate!!.year)

                        val calender: Calendar = Calendar.getInstance()
                        calender.add(Calendar.DATE, 1);

                        if (showDialogBox!!.calendarView.selectedDate!!.month + 1 > 12){
                            var year = showDialogBox!!.calendarView.selectedDate!!.year + 1

                            showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,
                                1,
                                1), true);
                        }else {
                            showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(showDialogBox!!.calendarView.selectedDate!!.year,
                                showDialogBox!!.calendarView.selectedDate!!.month +1,
                                1), true);
                        }

                        Log.e("call","@@@ selected "+showDialogBox!!.calendarView.selectedDates.size)
                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                    }else {
                        ////  increment dates

                        val calender: Calendar = Calendar.getInstance()
                        calender.add(Calendar.DATE, 1);
                        var day = showDialogBox!!.calendarView!!.selectedDate!!.day + 1
                        val month =  showDialogBox!!.calendarView.selectedDate!!.month
                        val year =  showDialogBox!!.calendarView.selectedDate!!.year
                        showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), true);


                        showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                    }

                    Log.e("call","DAY SELECT:-----   "+showDialogBox!!.calendarView.selectedDates.toString())

                    lastDaySelect = showDialogBox!!.calendarView.selectedDate!!.day
                }else {
                 Log.e("call","@@@ NO DATE SELECTED...")
                    showDialogBox!!.calendarView.setDateSelected(CalendarDay.today(), true);
                    showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)
                }

            }catch (exption:java.lang.Exception){
                Log.e("call","@@@exception  "+exption.toString())
            }


        }

        // minus button
        showDialogBox!!.llminus.setOnClickListener {

            try {

                if (showDialogBox!!.calendarView.selectedDates.size > 0){
                    if (showDialogBox!!.calendarView.selectedDate!!.day == 1){
                        showDialogBox!!.calendarView.goToPrevious()
                    }

                    val calender: Calendar = Calendar.getInstance()
                    calender.add(Calendar.DATE, 1);
                    var day = showDialogBox!!.calendarView!!.selectedDate!!.day
                    val month =  showDialogBox!!.calendarView.selectedDate!!.month
                    val year =  showDialogBox!!.calendarView.selectedDate!!.year
                    showDialogBox!!.calendarView.setDateSelected(CalendarDay.from(year,month,day), false);
                    showDialogBox!!.tvCount.setText(""+showDialogBox!!.calendarView.selectedDates.size)

                    lastDaySelect = showDialogBox!!.calendarView.selectedDates.get(showDialogBox!!.calendarView.selectedDates.size - 1).day

                    Log.e("call","DAY SELECT:-----   "+showDialogBox!!.calendarView.selectedDates.toString())
                }

            }catch (e:java.lang.Exception){
                Log.e("call","exception "+e.toString())
            }


        }

        // check availability

        showDialogBox!!.tvCheckAvailability.setOnClickListener {

            if(showDialogBox!!.calendarView.selectedDates.size > 0){
                var date = ""+showDialogBox!!.calendarView.selectedDates.get(0).year+"-"+showDialogBox!!.calendarView.selectedDates.get(0).month+"-"+showDialogBox!!.calendarView.selectedDates.get(0).day
                var daysCount = showDialogBox!!.calendarView.selectedDates.size

                Log.e("call","@@@123 date  "+date)
                Log.e("call","@@@123 daysCount  "+daysCount)
                Log.e("call","@@@123 clientInvoiceId  "+clientInvoiceId)

                var dayPassBody = DayPassRequest(
                    ""+clientInvoiceId,""+date,""+daysCount
                )
                viewModel.dayPassAvailibilityRequest(dayPassBody, pref.getString(Constants.TOKEN))
                showDialogBox!!.dismiss()
            }
            else {
                showShortToast("please select any date first")
            }
        }

        showDialogBox!!.tvCancelAvailability.setOnClickListener {
            showDialogBox!!.dismiss()
        }

    }

    private fun setObserver() {

        viewModel.dayPassSuccess.observe(requireActivity(), {

            if (it.message != "Success") {

//                showShortToast(it.message!!)
            } else {

                showDialogBox!!.setContentView(R.layout.calender_date_proceed_pop_up)
                showDialogBox!!.setCanceledOnTouchOutside(true)
                showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
                val layoutManager = LinearLayoutManager(requireContext())
                layoutManager.orientation = LinearLayoutManager.VERTICAL
                showDialogBox!!.show()
                showDialogBox!!.tvResponse.setText("Total cost for selected date(s) :"+"$"+it!!.model!!.daypassTotalCost)
                showDialogBox!!.tvProceed.setOnClickListener {

                    acceptAndPayPopup(agreementName)
                }
                showDialogBox!!.tvCancel.setOnClickListener {
                    showDialogBox!!.dismiss()
                }

                //    showShortToast(it.message!!)
            }

        })


        viewModel.preApprovalRequestSuccess.observe(requireActivity(), {

            showDialogBox!!.dismiss()
            tvLicenceNow.setText(getString(R.string.cancel_request))
            showRequestSubmitted()

        })



        viewModel.getPaymentTokenResponse.observe(requireActivity(), {

            val fragment = PaymentWebViewFragment()
            bundle.putString(Constants.PAYMENT_TOKEN, it.model.response.paymentToken)
            bundle.putString("publickey", key)
            fragment.setArguments(bundle)
            addNewFragment(fragment, R.id.container, true)

        })


        viewModel.cancelRequestSuccess.observe(requireActivity(), {

            if (it.message != "Success") {
//                showShortToast(it.message!!)
            } else {
                tvLicenceNow.setText("Request Pre-Approval")
//                showShortToast(it.message!!)
            }

        })


        tvSubmitPA.setOnClickListener {
            LeaveUsMessage()
        }


        viewModel.rightOfEntryResponseSuccess.observe(requireActivity(), {

            Log.d("@@@@", "Success")

            Log.e("call", "list " + it!!.model.toString())

            if (it.message != "Success") {
//                showShortToast(it.message!!)
            } else {
                showDialog("Your request for temporary access is submitted.")
//                showShortToast(it.message!!)
            }

        })


        viewModel.dayPassSuccess.observe(requireActivity(), androidx.lifecycle.Observer {
            if (it.message != "Success") {
                showShortToast(it.message!!)
            } else {

            }
        })

        viewModel.sendMessageResponseSuccess.observe(requireActivity(), androidx.lifecycle.Observer {
            if (it.message != "Success") {
                showShortToast(it.message!!)
            } else {
                showDialogBox!!.dismiss()
                leaveusMessagesSuccess()
                //tvShowResponse.setText("Property Agent has been notified.You can view all your messages and responses in the Message Center.")

                //showShortToast(it.message!!)
            }
        })

        viewModel.licenceSuccess.observe(requireActivity(), androidx.lifecycle.Observer {


            Log.d("@@@@", "Success")

            Log.e("call", "list " + it!!.model.toString())



            if (it.message != "Success") {
//                showShortToast(it.message!!)
            } else {
//                setViewPager
                try {


                    if (it!!.model.activityDetail.activityType == "Day Pass") {

                        tvDayPass.visibility = View.VISIBLE
                    } else {

                        tvDayPass.visibility = View.GONE
                    }



                    /* if (it!!.model.activityDetail.activityType == "Day Pass") {
                         tvLicenceNow.setText("Select")

                     }*/





                    if (it!!.model.images.size > 0 && it!!.model.images != null) {
                        ivPlaceHolder.visibility = View.GONE
                        val viewPagerAdapter = ViewPagerAdapter(requireContext(), it!!.model.images)
                        viewPager.adapter = viewPagerAdapter

                        if (it!!.model.images.size == 1) {

                        } else {
                            dotFunctionality(viewPagerAdapter)
                        }

                    } else {
                        viewPager.visibility = View.GONE
                        ivPlaceHolder.visibility = View.VISIBLE
                    }
                } catch (e: Exception) {
                    Log.e("call", "Exception " + e.toString())
                }

                if (it.model.activityDetail.agreementName!=null){
                    agreementName = it.model.activityDetail.agreementName
                }

                clientInvoiceId = it.model.activityDetail.licenseActivityID
                licenceFee = it.model.activityDetail.licenseFee
                productTypeID = it.model.activityDetail.productTypeID
                prodID = it.model.activityDetail.productID
                productID = it.model.activityDetail.productID.toString()

                rluNo = it.model.activityDetail.displayName
//                agreementName=it.model.activityDetail.agreementName
                isUserProfileComplete = it.model.activityDetailPageChecks.isUserProfileComplete
                preApprRequestID = it.model.activityDetailPageChecks.preApprRequestID.toString()


                if (it!!.model!!.activityDetailPageChecks.showComingSoonButton == true) {
                    tvLicenceNow.setText("Coming Soon")
                    tvLicenceNow.setClickable(false)
                } else if (it!!.model!!.activityDetailPageChecks.preApprovalStatus == "Accepted") {
                    tvLicenceNow.setText("Select")
                    tvLicenceNow.setClickable(true)

                } else if (it!!.model!!.activityDetailPageChecks.isPreApprovalRequested == true && it!!.model!!.activityDetailPageChecks.preApprovalStatus == "Requested") {
                    tvLicenceNow.setText("Cancel Request")
                    tvLicenceNow.setClickable(true)
                } else if (it!!.model!!.activityDetailPageChecks.showPreApprovalRequestButton == true) {
                    tvLicenceNow.setText("Request Pre-Approval")
                    tvLicenceNow.setClickable(true)
                } else if (it!!.model!!.activityDetailPageChecks.showRenewButton == true) {
                    tvLicenceNow.setText("Renew License")
                    tvLicenceNow.setClickable(false)

                } else if (it!!.model!!.activityDetailPageChecks.showLicenseNowButton == true && it!!.model!!.activityDetail.activityType != "Day Pass") {
                    tvLicenceNow.setText("Select")
                    tvLicenceNow.setClickable(true)

                } else if (it!!.model!!.activityDetail.activityType == "Day Pass") {
                    tvLicenceNow.setText("Select")
                    tvLicenceNow.setClickable(true)
                } else if (it!!.model!!.activityDetailPageChecks.showAlreadyPurchasedButton == true) {
                    tvLicenceNow.setText("Already Purchased")
                    tvLicenceNow.setClickable(false)
                } else if (it!!.model!!.activityDetailPageChecks.showSoldOutButton == true) {
                    tvLicenceNow.setText("Sold Out")
                    tvLicenceNow.setClickable(false)
                }

                tvHplNorthDesc.setText("" + it!!.model!!.activityDetail.displayName)
                tvHplNorthPrice.setText("$"+it!!.model!!.activityDetail.licenseFee)
                tvAddress.setText("" + it!!.model!!.activityDetail.countyName + ", " + it!!.model!!.activityDetail.state)
                tvPropertyID.setText("" + it!!.model!!.activityDetail.productNo)
                tvPriceDec.setText("$" + it!!.model!!.activityDetail.licenseFee)
                tvAcres.setText("" + it!!.model!!.activityDetail.acres)
                var startDate = dateFormat(it!!.model!!.activityDetail.licenseStartDate)
                var endDate = dateFormat(it!!.model!!.activityDetail.licenseEndDate)

                tvLicenceStartDateDesc.setText("" + startDate)
                tvLicenceEndDateDec.setText("" + endDate)


//                if (it!!.model!!.specialConditions != null) {
//                    tvSpecialConditions.setText("$" + it!!.model!!.specialConditions)
//
//                } else {
//                    Log.e("@@@", "it!!.model!!.specialConditions" + it!!.model!!.specialConditions)
//                    tvSpecialConditions.setText("No special Conditions")
//                }

                tvPropertyDescription.setText("" + it!!.model!!.activityDetail.displayDescription)
                // tvContactPAgent.setText("" + it!!.model!!.activityDetail.phone)



                var accPhone: String = it!!.model!!.activityDetail.phone

                if (accPhone != null) {
                    if (accPhone.length >= 10) {
                        var phoneNumber = "" + accPhone
                        var open = "("
                        var close = ")"
                        var code = " "
                        code = open + phoneNumber.substring(
                            0,
                            3
                        ) + close + " " + phoneNumber.substring(
                            3,
                            6
                        ) + "-" + phoneNumber.substring(6, 10)
                        tvContactPAgent.setText(code)
                    } else {
                        tvContactPAgent.setText(accPhone)
                    }
                }



                tvTime.setText("8:00 AM - 5:00 PM M-F EST")


                //    tvTime.setText("" + it!!.model!!.activityDetail.timeZone + "" + it!!.model!!.activityDetail.timeZone)


                if (it!!.model!!.activityDetail.displayDescription == null) {
                    tvPropertyDescription.setText("No Description Available")
                } else {
                    tvPropertyDescription.setText("" + it!!.model!!.activityDetail.displayDescription)
                }

                //       Log.e("call","@@@ amenities list "+it!!.model.amenities)


                list1.clear()
                list2.clear()

                try {
                    if (it!!.model.amenities!=null) {
                        for (i in 0 until it!!.model.amenities.size) {
                            if (it!!.model.amenities.get(i).amenityType.equals("Activity")) {
                                list1.add(it.model.amenities.get(i))
                            }
                        }
                        rvActivitiesLN.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
                        rvActivitiesLN.adapter = LicenseNowAmenityAdapter(list1, activity)
                    }
                }catch (e:Exception){
                    Log.e("call","exp23333:  "+e.toString())
                }


                try {
                    if (it!!.model.amenities!=null) {
                        for (i in 0 until it!!.model.amenities.size) {
                            if (it!!.model.amenities.get(i).amenityType.equals("Amenity")) {
                                list2.add(it.model.amenities.get(i))
                            }
                        }
                        rvAmenitiesLN.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
                        rvAmenitiesLN.adapter = LicenseNowAmenityAdapter(list2, activity)
                    }
                }catch (e:Exception){
                    Log.e("call","exp23333:  "+e.toString())
                }


                ///////////

                if (list1.isEmpty()) {
                    rvActivitiesLN.visibility = View.GONE
                    tvNoActivityAvailable.visibility = View.VISIBLE
                } else {
                    rvActivitiesLN.visibility = View.VISIBLE
                    tvNoActivityAvailable.visibility = View.GONE
                }

                if (list2.isEmpty()) {
                    rvAmenitiesLN.visibility = View.GONE
                    tvNoAmenityAvailableHome.visibility = View.VISIBLE
                } else {
                    rvAmenitiesLN.visibility = View.VISIBLE
                    tvNoAmenityAvailableHome.visibility = View.GONE
                }

                Log.e("call","@@@ SPECIAL CONDITION: "+it.model.specialConditions.toString())

                try {
                    list3.clear()

                    for (i in 0 until it!!.model.specialConditions.size) {
                        list3.add(it.model.specialConditions.get(i))
                    }

                    rvSpecialConditions.layoutManager =
                        LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
                    rvSpecialConditions.adapter = LicenseGuideLineHomeAdapter(list3, activity)
                } catch (e: Exception) {
                    Log.e("call", "Exception:  " + e.toString())
                }

                Log.e("call", "@@@@ LIST3 " + list3.toString())

                if (list3.isEmpty()) {
                    rvSpecialConditions.visibility = View.GONE
                    tvSpecialConditions.visibility = View.VISIBLE

                    Log.e("call", "@@@@ LIST3 232")
                } else {
                    rvSpecialConditions.visibility = View.VISIBLE
                    tvSpecialConditions.visibility = View.GONE

                    Log.e("call", "@@@@ LIST3 677")
                }
                data.clear()
                if (it!!.model.similarProperties.size > 0 && it!!.model.similarProperties!=null) {
                    for (i in 0 until it!!.model.similarProperties.size) {
                        data.addAll(listOf(it!!.model.similarProperties.get(i)))
                    }
                }

                rvSimilarPropertiesHV.layoutManager =
                    LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
                //creating a  arraylist of data
                rvSimilarPropertiesHV.adapter = SimilarPropertiesAdapter(data, this)
//                showShortToast(it.message!!)

                if (data.isEmpty()) {
                    rvSimilarPropertiesHV.visibility = View.GONE
                    tvSimilarProperties.visibility = View.VISIBLE
                } else {
                    rvSimilarPropertiesHV.visibility = View.VISIBLE
                    tvSimilarProperties.visibility = View.GONE
                }
            }
        })

        viewModel.isLoading.observe(requireActivity(), androidx.lifecycle.Observer {
            if (it) {
                progressBarPB.show()
            } else {
                progressBarPB.dismiss()
            }
        })

    }

    private fun leaveusMessagesSuccess() {

            showDialogBox1!!.setContentView(R.layout.leave_us_message_success)
            showDialogBox1!!.setCanceledOnTouchOutside(true)
            showDialogBox1!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
            val layoutManager = LinearLayoutManager(requireContext())
            layoutManager.orientation = LinearLayoutManager.VERTICAL
            val tvShowResponse: TextView = showDialogBox1!!.findViewById<TextView>(R.id.tvShowResponse)
            tvShowResponse.setText("Property Agent has been notified.You can view all your messages and responses in the Message Center.")
            showDialogBox1!!.show()
            Handler(Looper.getMainLooper()).postDelayed({
                showDialogBox1!!.cancel()
            }, 2000)

            val lp = WindowManager.LayoutParams()
            lp.copyFrom(showDialogBox1!!.getWindow()!!.getAttributes())
            lp.width = WindowManager.LayoutParams.MATCH_PARENT
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT
            lp.gravity = Gravity.CENTER
            showDialogBox1!!.getWindow()!!.setAttributes(lp)

    }

    private fun LeaveUsMessage() {

        showDialogBox!!.setContentView(R.layout.leave_us_message_box)
        showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
        showDialogBox!!.setCanceledOnTouchOutside(true)
        showDialogBox!!.tvSubmitMessage.setOnClickListener {

            if (showDialogBox!!.edtLeaveUsMessage.text.toString().equals("")){
                showShortToast("Please enter message")
            }else {
                // hit api send messages
                val sendMessageRequest = SendMessageRequest(   showDialogBox!!.tvSubmitMessage.text.toString(), productID.toInt())
                viewModel.sendMessagesRequest(sendMessageRequest, pref.getString(Constants.TOKEN))
            }

        }

        showDialogBox!!.tvCancelMessage.setOnClickListener {
            showDialogBox!!.hide()
        }
        showDialogBox!!.show()
    }

    private fun dotFunctionality(viewPagerAdapter: ViewPagerAdapter) {

        dotscount = viewPagerAdapter.count

        Log.e("####", "dotscount    ........" + dotscount)
        //   dots = arrayOf(arrayOf<ImageView>()[dotscount])
        val dots: Array<ImageView?> = arrayOfNulls(dotscount)
        //  var dots = arrayOfNulls(dotscount)
        for (i in 0 until dotscount) {
            dots[i] = ImageView(context)
            dots[i]!!.setImageDrawable(
                ContextCompat.getDrawable(
                    requireActivity(),
                    R.drawable.non_active_dot
                )
            )
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(8, 0, 8, 0)
            SliderDots.addView(dots[i], params)
        }
        dots[0]!!.setImageDrawable(
            ContextCompat.getDrawable(
                requireActivity(),
                R.drawable.active_dot
            )
        )
        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(pos: Int) {
                Log.e("####", "onPageSelected........" + dotscount)
                for (i in 0 until dotscount) {
                    dots[i]!!.setImageDrawable(
                        ResourcesCompat.getDrawable(
                            requireActivity()!!.getResources(),
                            R.drawable.non_active_dot,
                            null
                        )
                    )
                }
                dots[pos]!!.setImageDrawable(
                    ResourcesCompat.getDrawable(
                        requireActivity().getResources(),
                        R.drawable.active_dot,
                        null
                    )
                )
                //showLongToast("Dots visible")

            }

            override fun onPageScrollStateChanged(state: Int) {}


        })
    }

    private fun acceptAndPayPopup(agreementName: String) {

        showDialogBox!!.setContentView(R.layout.popup_accept_and_pay)
        showDialogBox!!.setCanceledOnTouchOutside(true)
        showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
//        val layoutManager = LinearLayoutManager(requireContext())
//        layoutManager.orientation = LinearLayoutManager.VERTICAL

        val lp_ = WindowManager.LayoutParams()
        lp_.copyFrom(showDialogBox!!.getWindow()!!.getAttributes())
        lp_.width = WindowManager.LayoutParams.MATCH_PARENT
        lp_.height = WindowManager.LayoutParams.WRAP_CONTENT
        showDialogBox!!.getWindow()!!.setAttributes(lp_)

        var pdfViewAP: PDFView = showDialogBox!!.findViewById<PDFView>(R.id.pdfViewAP)
//        var documentWebView: WebView = showDialogBox!!.findViewById<WebView>(R.id.documentWebView)
        var tvAcceptAndPay: TextView = showDialogBox!!.findViewById<TextView>(R.id.tvAcceptAndPay)

        var ivClose: ImageView = showDialogBox!!.findViewById<ImageView>(R.id.ivClose)

        var url: String = Constants.AMENITIES_URL + "Assets/Agreements/" + agreementName

        RetrievePDFFromURL(pdfViewAP).execute(url)

        tvAcceptAndPay.setOnClickListener {
            val getPaymentTokenBody = GetPaymentTokenBody(
                "https://demov2.myoutdooragent.com/#/app/property?id="+key+"&PaymentStatus=fail",
                clientInvoiceId,
                pref.getString(Constants.USER_EMAIL),
                "http://demov2.myoutdooragent.com/#/app/property?id="+key+"&Error=fail",
                "acct_1GaRZZLWZ7bSejfX",
                licenceFee!!,
                pref.getString(Constants.USER_NAME),
                prodID,
                productTypeID,
                "MOA",
                "https://demov2.myoutdooragent.com",
                rluNo,
                pref.getString(Constants.userAccountID)
            )

            viewModel.getPaymentToken(getPaymentTokenBody, pref.getString(Constants.TOKEN))
            showDialogBox!!.cancel()
        }

        ivClose.setOnClickListener {
            showDialogBox!!.cancel()
        }

        showDialogBox!!.show()
    }


    class RetrievePDFFromURL(pdfView: PDFView) :
        AsyncTask<String, Void, InputStream>() {

        // on below line we are creating a variable for our pdf view.
        val mypdfView: PDFView = pdfView

        override fun onPreExecute() {
            super.onPreExecute()
//            LicenceAnotherFragment.licenceAnotherFragment.progressBarPB.show()
        }

        // on below line we are calling our do in background method.
        override fun doInBackground(vararg params: String?): InputStream? {
            // on below line we are creating a variable for our input stream.

            var inputStream: InputStream? = null
            try {
                // on below line we are creating an url
                // for our url which we are passing as a string.
                val url = URL(params.get(0))

                // on below line we are creating our http url connection.
                val urlConnection: HttpURLConnection = url.openConnection() as HttpsURLConnection

                // on below line we are checking if the response
                // is successful with the help of response code
                // 200 response code means response is successful

                if (urlConnection.responseCode == 200) {
                    // on below line we are initializing our input stream
                    // if the response is successful.
                    inputStream = BufferedInputStream(urlConnection.inputStream)

                }
            }
            // on below line we are adding catch block to handle exception
            catch (e: Exception) {
                // on below line we are simply printing
                // our exception and returning null
                e.printStackTrace()
                return null;
            }
            // on below line we are returning input stream.
            return inputStream;
        }

        // on below line we are calling on post execute
        // method to load the url in our pdf view.
        override fun onPostExecute(result: InputStream?) {
            // on below line we are loading url within our
            // pdf view on below line using input stream.
//            LicenceAnotherFragment.licenceAnotherFragment.progressBarPB.dismiss()
            mypdfView.fromStream(result).load()

        }
    }


/*
    fun showAddDeleteDialog() {
        builder2 = AlertDialog.Builder(requireContext())
        builder2?.setMessage("Do you want to cancel your request for" + preApprRequestID)
            ?.setCancelable(false)
            ?.setPositiveButton("Delete", DialogInterface.OnClickListener { dialog, id ->
                removeitem(preApprRequestID)
                dialog.dismiss()
            })
            ?.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, id ->
                dialog.cancel()

            })
        val alert: AlertDialog = builder!!.create()
        alert.show()
    }
*/


    fun removeitem(preApprRequestID: String?) {
        pref = SharedPref(requireContext())
        val preApprovalCancelbody = PreApprovalCancelRequestBody(preApprRequestID)


        viewModel.preApprovalCancelRequest(preApprovalCancelbody, pref.getString(Constants.TOKEN))
    }


    private fun requestAccessPopup() {

        showDialogBox!!.setContentView(R.layout.poup_right_of_entry_request_form)
        showDialogBox!!.setCanceledOnTouchOutside(true)
        showDialogBox!!.getWindow()!!.setBackgroundDrawableResource(android.R.color.transparent)
        val layoutManager = LinearLayoutManager(requireContext())
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        var tvDateName: TextView = showDialogBox!!.findViewById<TextView>(R.id.tvDateName)
        var edtFLNameOne: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtFLNameOne)
        var edtFLNameTwo: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtFLNameTwo)
        var edtFLNameThree: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtFLNameThree)
        var edtFLNameFour: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtFLNameFour)
        var edtFLNameFive: EditText = showDialogBox!!.findViewById<EditText>(R.id.edtFLNameFive)
        var tvCancelDialog: TextView = showDialogBox!!.findViewById<TextView>(R.id.tvCancelDialog)
        var tvSaveDialog: TextView = showDialogBox!!.findViewById<TextView>(R.id.tvSaveDialog)

        var combinedNames =
            edtFLNameOne.text.toString() + edtFLNameTwo.text.toString() + edtFLNameThree.text.toString() + edtFLNameFour.text.toString() + edtFLNameFive.text.toString()

        val dateSetListener = object : DatePickerDialog.OnDateSetListener {
            override fun onDateSet(
                view: DatePicker, year: Int, monthOfYear: Int,
                dayOfMonth: Int
            ) {
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                updateDateInView(tvDateName)
            }
        }

        tvDateName.setOnClickListener {
            DatePickerDialog(
                requireActivity(),
                dateSetListener,
                // set DatePickerDialog to point to today's date when it loads up
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
            ).show()
        }


        tvSaveDialog.setOnClickListener {
            if (tvDateName.text.toString().equals("")) {
                showAlert("Please select entry date")
            } else {
                if (combinedNames.isEmpty()) {
                    combinedNames = ""
                }
                val myFormat = "yyyy-MM-dd" // mention the format you need
                val sdf = SimpleDateFormat(myFormat, Locale.US)
                tvDateName!!.text = sdf.format(cal.getTime())
                var rightOfEntryBody = RightOfEntryBody(
                    "", "", "" + tvDateName.text.toString(), "", "" + productID, "",
                    "0", "" + combinedNames, "", "", pref.getString(Constants.userAccountID), ""
                )
                viewModel.rightOfEntryRequest(rightOfEntryBody, pref.getString(Constants.TOKEN))

                Handler(Looper.getMainLooper()).postDelayed({
                    showDialogBox!!.cancel()
                }, 3500)
            }

//            showDialogBox!!.cancel()

        }

        tvCancelDialog.setOnClickListener {
            showDialogBox!!.cancel()
        }

        showDialogBox!!.show()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(showDialogBox!!.getWindow()!!.getAttributes())
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.gravity = Gravity.CENTER
        showDialogBox!!.getWindow()!!.setAttributes(lp)
    }

    private fun updateDateInView(textview: TextView) {
        val myFormat = "dd/MM/yyyy" // mention the format you need
        val sdf = SimpleDateFormat(myFormat, Locale.US)
        textview!!.text = sdf.format(cal.getTime())
    }

    override fun onChatListListener(index: Int) {
        var publickey = data.get(index).publicKey
        bundle.putString("publickey", publickey)
        Log.e("call", "publickey Active " + publickey)
//      val fragment = LicenceNowFragment()
        val fragment = LicenceFragment()
        val bundle = Bundle()
        bundle.putString("publickey", publickey)
        fragment.setArguments(bundle)
        addNewFragment(fragment, R.id.container, true)

        PreApprovalRequestFragment.isBackPreApproval = false
    }




    override fun onMapReady(googleMap: GoogleMap) {
//        val sydney = LatLng(-33.852, 151.211)
//        googleMap.addMarker(
//            MarkerOptions()
//                .position(sydney)
//                .title("Marker in Sydney")
//        )

        googleMap.getUiSettings().setZoomGesturesEnabled(true);

    }

    private class PrimeDayDisableDecorator : DayViewDecorator {
        override fun shouldDecorate(day: CalendarDay): Boolean {
            val date = CalendarDay.today()
            return if (day.isBefore(date)) true else false
        }

        override fun decorate(view: DayViewFacade) {
            view.setDaysDisabled(true)
        }
    }

    fun getLastDayOf(month: Int, year: Int): Int {
        return when (month) {
            Calendar.APRIL, Calendar.JUNE, Calendar.SEPTEMBER, Calendar.NOVEMBER -> 30
            Calendar.FEBRUARY -> {
                if (year % 4 == 0) {
                    29
                } else 28
            }
            else -> 31
        }
    }


    fun showRequestSubmitted() {
        builder = AlertDialog.Builder(requireActivity())
        builder?.setTitle("Submitted")
        builder?.setMessage("Pre-Approval Request Submitted.")
            ?.setCancelable(false)
            ?.setPositiveButton("Ok", DialogInterface.OnClickListener { dialog, id ->
                dialog.dismiss()
            })

        val alert: AlertDialog = builder!!.create()
        alert.setOnShowListener(DialogInterface.OnShowListener {
            alert.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(requireActivity().getResources().getColor(R.color.green))
        })

        alert.show()
    }

}





