package com.myoutdoor.agent.models.licensedetails.formylicense.license

data class SpecialCondition(
    var specCndDesc: String,
    var specCndID: Int
)