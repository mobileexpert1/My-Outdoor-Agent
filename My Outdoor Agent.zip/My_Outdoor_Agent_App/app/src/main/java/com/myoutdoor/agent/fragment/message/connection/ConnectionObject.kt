package com.myoutdoor.agent.fragment.message.connection

class ConnectionObject {
    var methodName: String = ""
    var arguments: List<String> =ArrayList<String>()

}