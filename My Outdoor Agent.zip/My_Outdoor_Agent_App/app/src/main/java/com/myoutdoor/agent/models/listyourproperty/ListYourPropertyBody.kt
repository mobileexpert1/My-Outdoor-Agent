package com.myoutdoor.agent.models.listyourproperty

data class ListYourPropertyBody(
    var Email: String,
    var FirstName: String,
    var LandownerType: String,
    var LastName: String,
    var Phone: String
)