package com.myoutdoor.agent.fragment.licence.model

data class Image(
    val caption: Any,
    val imageFileName: String="",
    val productID: Int=0,
    val productImageID: Int=0
)