package com.myoutdoor.agent.models.preapprovalrequest.cancelrequest

data class PreApprovalCancelRequestBody(
    var preApprRequestID: String?
    )