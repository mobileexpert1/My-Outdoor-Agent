package com.myoutdoor.agent.fragment.contactus

import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.myoutdoor.agent.R

import com.myoutdoor.agent.activities.MainActivity
import com.myoutdoor.agent.models.contactus.ContactUsBody
import com.myoutdoor.agent.utils.BaseFragment
import com.myoutdoor.agent.utils.Constants
import com.myoutdoor.agent.utils.SharedPref
import kotlinx.android.synthetic.main.fragment_contact_us.*
import kotlinx.android.synthetic.main.toolbar.*


class ContactUsFragment : BaseFragment() {

    lateinit var viewModel: ContactUsViewModel
    lateinit var pref: SharedPref


    override fun getLayoutId(): Int {
        return R.layout.fragment_contact_us
    }

    override fun onCreateView() {
        tvToolbar.setText("Contact Us")
        pref= SharedPref(requireContext())
        viewModel = ViewModelProvider(this).get(ContactUsViewModel::class.java)

        setObserver()
//        backpress button
        ivBackpress.setOnClickListener {
            MainActivity.mainActivity.bottomNav.visibility= View.VISIBLE
            requireActivity().onBackPressed()
        }

        fragmentBackPressHandle()

        tvContactusSubmit.setOnClickListener {
            if (edtName.text.isEmpty()) {
                showShortToast("Please enter name.")
            } else if (edtEmail.text.isEmpty()) {
                showShortToast("Please enter Email name.")
            } else if (edtDescription.text.isEmpty()) {
                showShortToast("Please enter description")
            }  else if (!isEmailValid(edtEmail.text.toString())) {
                showShortToast("Please enter valid email.")
            } else  {
                val contactUsBody = ContactUsBody(
                    edtDescription.text.toString(),
                    edtEmail.text.toString(),
                    edtName.text.toString()
                )
                viewModel.contactUsRequest(contactUsBody,pref.getString(Constants.TOKEN))
            }
        }

    }

    fun setObserver() {

        viewModel.contactUsSuccess.observe(requireActivity(), Observer {
            Log.d("@@@@", "Success")
            // check for unactivated account
            if (it.message!="Success"){
//                showShortToast(it.message!!)
                edtName.setText("")
                edtEmail.setText("")
                edtDescription.setText("")
                showPopup()
            }
            else {
//                showShortToast(it.message!!)
            }
        }
        )

        viewModel.apiError.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed")
            showShortToast(it)
        }
        )

        viewModel.isLoading.observe(requireActivity(), Observer {
            Log.d("@@@@", "Failed")
            if (it) {
                progressBarPB.show()
            }
            else {
                progressBarPB.dismiss()
            }
        }
        )

    }

    fun showPopup(){
        val builder = AlertDialog.Builder(requireContext())

        builder.setMessage(getString(R.string.thank_you_we_have_received_your_message_someone_from_our_time_will_contact_you_soon))

        // builder.setNegativeButton("Ok", null)
        builder.setPositiveButton(
            "Ok"
        ) { dialog, which ->
            requireActivity().onBackPressed()
        }

        val dialog = builder.create()

        dialog.show()
    }


}